# Smart Campus Hub – Student Life OS

A Java Swing desktop app backed by MySQL 8 and JDBC. The interface has exactly five main areas: Authentication and Role-Based Dashboards, Attendance Management, Assignment Management, Quiz and Result Management, and Campus Events and Notifications.

## Requirements

- JDK 17 or newer (developed and compiled with JDK 26)
- MySQL Server 8
- Windows build scripts use the included MySQL Connector/J library in `lib/`

## Run the configured local project

This workspace has been configured with its local MySQL connection, project database, sample data, and a one-time administrator. Start the **MySQL80** service, then open `dist\release-final\SmartCampusHub\SmartCampusHub.exe`. The earlier app image at `dist\SmartCampusHub` is preserved as the baseline build. You can also run `run.bat` from this folder.

Administrator email: `admin@campus.com`. Its generated password is saved in the private, git-ignored `local-admin.txt` file. The five faculty names, subject assignments, and demo sign-ins are listed in `DATABASE/README.md`.

For a fresh setup or troubleshooting, follow [`DOCUMENTS/RUN_GUIDE.md`](DOCUMENTS/RUN_GUIDE.md). The app searches from its current folder and the application JAR's parent folders for `local.properties`, so the packaged app can find the project settings when launched directly.

Sample faculty and student accounts are described in `DATABASE/README.md`. There is no public registration form. Faculty can only access their courses; students see their own records and enrolled courses. The authenticated role is taken from the database session.

## Build, launch, and packaging

- `build.bat` compiles source to `build/classes`.
- `run.bat` builds and launches the Swing app.
- `test-db.bat` checks the configured MySQL connection and expected tables.
- MySQL Server must be running. Local credentials stay in the ignored `local.properties` file; they are not packaged or committed.

The source tree is under `src/main/java/campus`; each of the five main module screens is implemented under `campus.ui`. Database setup, sample records, and reset instructions are under `DATABASE`.

## Current scope

Attendance entry, assignment creation and student text submission, faculty submission review/grading, multiple-choice quiz authoring/attempts/automatic scoring, event creation, notice publishing and student read status are connected to MySQL. Student self-registration and admin account/course/enrolment management are available. Admin-assisted password changes are provided; email reset links are not configured. File attachments and external email/SMS/push delivery are not included. See [the upgrade handoff](DOCUMENTS/UPGRADE_HANDOFF.md) and [the verification report](TESTING/TEST_RESULTS.md). The upgraded Windows app image is in `dist\release-final\SmartCampusHub`.
