@echo off
setlocal
set "JAVA_BIN="
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\javac.exe" set "JAVA_BIN=%JAVA_HOME%\bin"
if not defined JAVA_BIN for /d %%D in ("%ProgramFiles%\Java\jdk-*") do if exist "%%~D\bin\javac.exe" set "JAVA_BIN=%%~D\bin"
if exist build\classes rmdir /s /q build\classes
mkdir build\classes
if defined JAVA_BIN (
  "%JAVA_BIN%\javac.exe" -encoding UTF-8 -cp "lib\mysql-connector-j-26.7.0.jar" -d build\classes src\main\java\campus\*.java src\main\java\campus\ui\*.java
) else (
  javac -encoding UTF-8 -cp "lib\mysql-connector-j-26.7.0.jar" -d build\classes src\main\java\campus\*.java src\main\java\campus\ui\*.java
)
if errorlevel 1 exit /b 1
echo Build successful.
