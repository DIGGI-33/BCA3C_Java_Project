# Smart Campus Hub: step-by-step Windows run guide

Follow these steps the first time you set up the project. You do not need Eclipse.

## Launch the already configured copy on this PC

This project copy already has its MySQL connection, database, sample data, and first administrator prepared. Start **MySQL80**, then double-click `dist\release-final\SmartCampusHub\SmartCampusHub.exe`. Sign in as `admin@campus.com`; the generated password is in the private `local-admin.txt` file in the project root. Do not run the initial admin bootstrap again. Continue below only if setting up a fresh copy or troubleshooting.

## 1. Start MySQL Server

1. Press **Windows**, type **Services**, and open the Services app.
2. Find **MySQL80** (or the MySQL Server service installed on your PC).
3. If its status is not **Running**, right-click it and choose **Start**.
4. Open **MySQL Workbench** and connect to your local MySQL server. Use the same MySQL account and password you will put in `local.properties` below.

If Workbench cannot connect, fix that connection first. The desktop app cannot connect while the MySQL service is stopped or its connection details are wrong.

## 2. Create the project database and tables

1. In Workbench, choose **File → Open SQL Script**.
2. Open `C:\SEM 3 BCA\BCA3C_JAVA_PROJECT\DATABASE\schema.sql`.
3. Confirm that the active Workbench connection is your local MySQL server, then click the lightning-bolt **Execute** button to run the script.
4. Wait for the action/output panel to show the statements completed without errors. The script creates the `smart_campus_hub` database and its tables. It does not drop an existing database.

## 3. Load the demonstration records

1. In Workbench, open `C:\SEM 3 BCA\BCA3C_JAVA_PROJECT\DATABASE\sample_data.sql`.
2. Click the lightning-bolt **Execute** button and wait for it to finish.
3. Optional check: in Workbench's SCHEMAS panel, refresh the list, expand `smart_campus_hub`, then expand **Tables**.

Do **not** run `DATABASE/reset_database.sql` for ordinary setup. It deletes the project database and its data.

## 4. Set the local database login for the Java app

1. Open File Explorer and go to `C:\SEM 3 BCA\BCA3C_JAVA_PROJECT`.
2. Copy `local.properties.example` and rename the copy to `local.properties` (make sure Windows did not name it `local.properties.txt`).
3. Open `local.properties` in Notepad.
4. Set `db.user` to the MySQL username you used in Workbench (often `root`).
5. After `db.password=`, enter that account's MySQL password. Do not add quotes. Save and close the file.

Example only (replace the sample password with your own local MySQL password):

```properties
db.url=jdbc:mysql://localhost:3306/smart_campus_hub?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Kolkata
db.user=root
db.password=your-local-mysql-password
```

Keep `local.properties` private. It is excluded from Git. Do not send the password in chat or put it in a screenshot.

## 5. Open Command Prompt in the project folder

1. Press **Windows**, type **Command Prompt**, and open it.
2. Paste this command and press **Enter**:

```bat
cd /d "C:\SEM 3 BCA\BCA3C_JAVA_PROJECT"
```

3. Check that the prompt now ends with `BCA3C_JAVA_PROJECT>`.

The project includes JDK 26-compatible scripts and its MySQL JDBC library. The build script compiles the code when needed.

## 6. Create your first administrator account

In that same Command Prompt, run:

```bat
run.bat --bootstrap-admin
```

Enter an email, display name, and a password of at least 12 characters when asked. The password will not appear on screen as you type. Keep it somewhere safe. The app stores a password hash. Initial admin setup is a local terminal operation, not a public sign-up page; a second bootstrap is refused once an admin exists.

If Windows says `run.bat` is not recognized, check that Command Prompt is still in `C:\SEM 3 BCA\BCA3C_JAVA_PROJECT`.

## 7. Check the database connection

Run:

```bat
test-db.bat
```

Success prints **Database connection passed** and the number of tables found. If it fails, check that MySQL80 is running, `local.properties` is in the project root, the username/password are correct, and you already ran `schema.sql`.

## 8. Launch and sign in

In Command Prompt, run:

```bat
run.bat
```

The first build may take a few seconds. The Smart Campus Hub sign-in window should open. Use one of these sample accounts:

| Account | Email | Password |
|---|---|---|
| DIGVIJAYSINH | `digvijaysinh@gmail.com` | `Campus@123` |
| Administrator | The email and password you chose in step 6 | Your chosen password |

Faculty and student sample users are created by `sample_data.sql`. The five faculty logins are listed in `DATABASE/README.md`. The administrator is created separately by the bootstrap step. To update an existing database to the official faculty list without resetting it, run `run.bat --setup-faculty` once.

## 9. Open the packaged Windows app image (optional)

After the project has been set up, you can run the packaged launcher from the project folder in Command Prompt:

```bat
dist\release-final\SmartCampusHub\SmartCampusHub.exe
```

The upgraded app image is built at `dist\release-final\SmartCampusHub`; earlier images remain available. Start MySQL before launching it. If you change application source, run `package.bat` to rebuild the release image. The packaged launcher and JAR database-check mode have been verified. Visual inspection covered the login and Student dashboard; database-backed module workflows passed rollback-safe integration checks. Full manual use by a real student, faculty, and administrator account is still recommended before demonstration.

## Common errors

- **Access denied for user** — The MySQL username/password in `local.properties` do not match your Workbench connection, or the password line is blank.
- **Communications link failure / connection refused** — Start the MySQL80 service and check that the URL uses the correct MySQL port (default `3306`).
- **Unknown database or missing tables** — Run `DATABASE/schema.sql`, then `DATABASE/sample_data.sql` in Workbench.
- **No sample login works** — Re-run `sample_data.sql`; use exact email spelling and `Campus@123` for the sample faculty/student users.
- **Bootstrap says an admin exists** — Initial setup already ran. Sign in using the admin credentials created at that time; bootstrap intentionally cannot create a second initial admin.
- **Build errors** — Confirm `java -version` works in Command Prompt and `lib\mysql-connector-j-26.7.0.jar` exists.

For the current test status and known feature limitations, see `TESTING\TEST_RESULTS.md` and `DOCUMENTS\UPGRADE_HANDOFF.md`.
