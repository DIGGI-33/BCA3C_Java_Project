# Baseline audit — 15 October 2026

## Architecture

- Java Swing desktop application; there is no browser website or HTTP server.
- `campus.Main` opens `LoginFrame`; successful authentication constructs `MainFrame` and one of the existing `campus.ui` panels.
- `campus.Database` finds `local.properties` and connects with MySQL Connector/J to MySQL 8.
- `campus.Security` uses salted PBKDF2-HMAC-SHA256 for password storage and verification.
- Existing UI modules: dashboard, attendance, assignments, quizzes/results, and events/notices.
- Database schema has 15 tables for user/course/enrolment, attendance, assignments/submissions, quizzes/attempts/answers, events/notices/read state, and initial-admin setup.

## Existing workflows

- Sign-in checks active accounts and uses the database role. Admin, faculty, and student dashboards show role-specific counts.
- Faculty can mark course attendance, create assignments and quizzes, review assignment submissions, publish quizzes, and see results.
- Students can view their own attendance, submit assignment text, attempt published quizzes once, and read notices.
- Faculty/admin can add events and publish audience-targeted notices.
- Build, run, database-check, and Windows packaging scripts already exist.

## Baseline risks and gaps

- Most screens use modal input prompts; attendance requires repeated prompts per student.
- Login is a basic two-column form with no registration, remember-email, or recovery path.
- There is no administrator user/course management interface.
- Quiz creation only adds one question per quiz, though the schema can store multiple questions.
- The app image depends on a running MySQL service and a local `local.properties`; MySQL is not bundled.
- Database calls run synchronously from Swing action handlers and can make the UI pause.
- The recorded checks cover compilation, packaging, database connectivity, and authentication, but not complete GUI workflows for every module.

## Data and safety

- No production data migration or reset was run for this audit.
- `local.properties` and `local-admin.txt` are private local files and must not be copied into reports, screenshots, or public packages.
- Keep the existing PBKDF2 implementation, authorization scoping, and foreign-key/unique constraints. Avoid destructive reset scripts during development.

## Upgrade approach

Improve the existing application incrementally. Compile before rebuilding the packaged app, preserve the existing app image, and record only checks that were actually performed. Prioritize the authentication experience and the most burdensome real workflow (attendance roster), then improve the shared screen design and test scope.
