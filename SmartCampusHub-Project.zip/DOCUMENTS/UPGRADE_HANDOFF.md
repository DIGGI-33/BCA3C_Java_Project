# Smart Campus Hub — Upgrade Handoff

Updated: 15 October 2026

## What changed in this upgrade

The existing Java Swing + MySQL application was improved in place. It remains a Windows desktop application; there is no browser website or embedded MySQL server.

### Authentication and profile

- Replaced the plain login form with a two-panel branded screen, role choice, show/hide password, remember-email preference, keyboard sign-in, and clear campus-account messaging.
- The selected role is checked against the role returned by database authentication; choosing Admin never grants Admin access.
- Added public Student-only account creation. It validates name/email/password confirmation, requires a 12-character password, uses the existing PBKDF2 hash, and relies on the unique email constraint to reject duplicates. New students need an administrator to enrol them in a course.
- Added password help that explains the installed local app has no configured email service. A user must contact an administrator; the Administration screen has a direct password-change function. No fake reset email is claimed.
- Added My Profile for name and password changes. Saving requires the current password, updates only the signed-in account, and hashes any new password. Email and role are read-only.
- Remembered data is the email and selected role only; passwords are not remembered.

### Application shell and dashboards

- Added a consistent navy, blue, gold, and light-neutral style, shared table/button/card helpers, a role-aware sidebar, active navigation state, sign-out confirmation, and a compact identity bar.
- Rebuilt dashboard cards with role-specific, database-derived counts.
- Added a My Profile route for every role and an Administration route only for Admin.

### Attendance

- Replaced the repeated per-student prompts with a roster dialog. Faculty choose a course and date, see enrolled students and saved statuses, set the whole roster Present or Absent, adjust individual statuses, reset to saved data, and save the session together.
- Saves use a transaction and keep the existing unique course/date session rule and student/session upsert behavior.
- Faculty course ownership is checked again at save time. Student attendance remains scoped to the signed-in student; faculty attendance remains scoped to their courses.

### Administration

- Added user search and role filters, creation of Student/Faculty accounts, account activation/deactivation, and administrator-set password changes. The interface cannot create Admin accounts, and a signed-in Admin cannot deactivate their own account.
- Added course creation, faculty reassignment, student enrolment by existing student email, and enrolment removal. Related academic records are retained; accounts/courses are not deleted.

### Quizzes and campus life

- Quiz authoring now supports multiple questions in one quiz, four options per question, correct-option selection, question points, and transaction-based quiz/question insertion. A quiz remains a draft until published. Existing scoring and one-attempt constraints are retained.
- Events and notices use the shared visual styles. Notices are filtered by audience with prepared SQL parameters and every role can mark its own selected notice read.

### Packaging

- The existing app image at `dist/SmartCampusHub` is preserved as the earlier baseline.
- `package.bat` builds the latest image at `dist/release-final/SmartCampusHub`; the earlier images remain available for comparison.
- The app image includes the Java runtime and Connector/J, but still requires MySQL80 (or another configured MySQL 8 service) to be running and valid private `local.properties` settings to be discoverable. MySQL itself is not bundled.

## Verification performed

- `build.bat`: passed after the changes.
- `test-db.bat`: passed; local MySQL connection found 15 tables.
- Password fixture test: passed for the demo password and rejected a wrong password.
- Login integration check: Admin, Faculty, and Student accepted with their configured accounts; an unknown account was rejected.
- Registration/profile integration test: a uniquely named temporary student was created, authenticated with role Student, had its name/password updated, rejected the old password, accepted the new one, rejected duplicate email, and was deleted after the test.
- JAR and upgraded Windows launcher database checks were run from `C:\Windows`; each found all 15 tables.
- The test registration user is cleaned up in a `finally` block. No database reset was run.

These checks verify compilation, authentication/profile database behavior, registration and the packaged connection path. They do not prove every graphical workflow is defect-free.

## Remaining work and honest limitations

- Full interactive GUI workflows were not manually exercised for every role/module, and visual screenshots were not captured.
- Assignment submissions remain text-only. Assignment edit/delete, late-submission policy, attachment handling, filters, and submission history are not implemented.
- Quiz authoring supports multiple MCQs, but question editing after creation and richer result analytics are not provided.
- Events cannot yet be edited/deleted and event/notice search, expiry, and filters are not implemented.
- User management includes search, role filtering, activation, and password changes, but profile edits beyond display name, enrollment-number fields, bulk import, and activity logs are absent.
- Forgot-password support is administrator-assisted only; no verified email reset token or delivery service is configured.
- Database work still runs synchronously on the Swing UI thread in several screens and can pause the UI if MySQL is slow.
- The existing local database connection uses the private local settings for this PC. A shared deployment should create a least-privilege MySQL account and use a proper installer/configuration process.

## Running the upgraded build

1. Start the MySQL80 Windows service.
2. Open `dist/release-final/SmartCampusHub/SmartCampusHub.exe`.
3. Sign in with an account whose database role matches the selected role. Existing demo and local Admin credentials are documented in the private local files and `DATABASE/README.md`; never publish `local.properties` or `local-admin.txt`.

Build the JAR and app image again with `package.bat`. The app image does not install or start MySQL.
