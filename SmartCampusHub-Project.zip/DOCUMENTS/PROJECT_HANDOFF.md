# Smart Campus Hub — Project Handoff

> This document describes the pre-upgrade baseline. For the current implementation, changes, verification results, and remaining limitations, read [UPGRADE_HANDOFF.md](UPGRADE_HANDOFF.md).

## 1. Project summary

Smart Campus Hub is a Windows desktop application for campus activity. It is built in Java with Swing screens and uses a local MySQL 8 database through JDBC. It groups student and faculty tasks into one application: attendance, assignments, quizzes/results, events/notices, and role-specific dashboards.

This handoff describes the current implementation in this project folder. It is a working classroom-project foundation, but some features and full GUI workflows still need testing and expansion (see sections 8–9).

## 2. What a user can do

The left navigation opens five areas:

1. **Authentication and dashboards**
   - Sign in with an email and password stored as a user record in MySQL.
   - The account has one of three roles: `ADMIN`, `FACULTY`, or `STUDENT`.
   - Each role gets different dashboard counts and access to different actions.
   - Sign out returns to the login window. There is no public registration form.

2. **Attendance**
   - Faculty can choose one of their assigned courses and a date, then record present/absent status for enrolled students.
   - The database permits one attendance session per course and date; re-saving that date updates the existing student records.
   - Faculty see records for their courses; students see their own attendance.

3. **Assignments**
   - Faculty can create an assignment for one of their courses, including instructions and a deadline.
   - Enrolled students can submit text. A student can update their submission; updating clears any previous marks and feedback.
   - Faculty can review submissions and give marks (0–100) and feedback. Students can see their submission, marks, and feedback.

4. **Quizzes and results**
   - Faculty can create a quiz for one of their courses. The current screen collects one multiple-choice question with four options and one correct answer per quiz.
   - Faculty can publish or close a quiz and view results.
   - Enrolled students can attempt published quizzes. The application calculates the score, saves answers and the attempt, and limits each student to one attempt per quiz.

5. **Events and notices**
   - Faculty and administrators can add campus events and publish notices for everyone, students, or faculty.
   - Users see upcoming events and notices for their audience. Students can mark a notice as read; read status is saved per user.

The dashboard displays database-derived counts. Student cards include attendance and unread notices; faculty cards include courses, assignments and submissions needing review; administrator cards show campus-wide counts.

## 3. Roles and data access

| Role | Main access in the current UI |
|---|---|
| `ADMIN` | Campus-wide dashboard and quiz results; can add events and publish notices. |
| `FACULTY` | Their assigned courses, attendance, assignments/submissions, quizzes/results, events and notices. |
| `STUDENT` | Own attendance, enrolled-course assignments and quizzes, own results/submissions, events and notices. |

Login looks up the active user by email and verifies the stored password hash. Module queries use the logged-in user ID to scope student records and faculty-owned work. This is a single-machine classroom application, not a hardened multi-user internet service.

## 4. How the pieces connect

```text
Windows launcher / JAR
        ↓
campus.Main → LoginFrame → Main.authenticate → Security.verify
        ↓                                  ↓
     MainFrame                         Database.connect
        ↓                                  ↓
 Swing module panels  ── JDBC / MySQL Connector/J ── MySQL 8
        ↓                                                   ↓
 dashboards and module actions                 smart_campus_hub tables
```

- **Interface:** Java Swing. `LoginFrame` handles sign-in; `MainFrame` provides navigation; panels under `campus.ui` display data and actions.
- **Application logic:** Each panel performs its module operation and refreshes its table after a change. JDBC prepared statements are used for most inserts/updates with user-provided values.
- **Database access:** `campus.Database` loads `local.properties`, loads the MySQL Connector/J driver, and opens JDBC connections. It searches the current directory and the application code/JAR directory and their parents for the properties file.
- **Authentication:** `campus.Security` stores/verifies PBKDF2-HMAC-SHA256 hashes with a random salt and 210,000 iterations. Plaintext passwords are not stored by the application.
- **Persistence:** Successful module actions write to MySQL, so records remain after the app closes, provided the same database is used.

The desktop app is not a website hosted in a browser. “Local server” here means the MySQL server service running on the same computer; the Java application connects to it at the configured host/port (normally `localhost:3306`).

## 5. Database design

The schema is in `DATABASE/schema.sql`. It creates the `smart_campus_hub` database and 15 tables:

| Table(s) | Purpose |
|---|---|
| `users` | Accounts, role, active status and password hash. |
| `courses`, `enrolments` | Faculty-owned courses and student/course membership. |
| `attendance_sessions`, `attendance_records` | Per-course/date attendance and each student's status. |
| `assignments`, `submissions` | Assignment details, student text submissions, marks and feedback. |
| `quizzes`, `quiz_questions`, `quiz_attempts`, `quiz_answers` | Quiz publishing, MCQ data, scores, attempts and selected answers. |
| `events` | Event date, location and description. |
| `notifications`, `notification_reads` | Audience-targeted notices and per-user read status. |
| `setup_control` | One-time initial-admin bootstrap state. |

Foreign keys link records to their users/courses. Unique keys prevent duplicate emails, enrolments, one attendance session for the same course/date, one submission per student/assignment, and one attempt per student/quiz. Demo records are in `DATABASE/sample_data.sql`; database reset instructions are in `DATABASE/reset_database.sql` and that script deletes project data.

## 6. Build, launch, and packaging work in this project

- `build.bat` compiles Java source in `src/main/java/campus` and `campus/ui` into `build/classes`, using the included `lib/mysql-connector-j-26.7.0.jar`.
- `run.bat` builds and starts the desktop application.
- `test-db.bat` checks that the configured MySQL database is reachable and has the expected tables.
- `package.bat` builds `build/package/SmartCampusHub.jar` with the Connector/J dependency beside it, then uses `jpackage` to create the Windows app image under `dist/SmartCampusHub`.
- The app image includes a Windows launcher and a bundled Java runtime. It still needs the local MySQL service and valid database settings/data; packaging the Java program does not package or start MySQL.
- `local.properties` contains this computer's database connection settings and is excluded from Git. Do not publish it or copy it to another PC without replacing its credentials. The generated admin credential file `local-admin.txt` is also private/ignored.
- The packaged launcher and JAR were checked from outside the project working folder and could find the local configuration. This verifies config lookup and database connection, not every screen's behavior.

## 7. Demo data and sign-in

`DATABASE/sample_data.sql` supplies two faculty accounts, eight students, two courses, course enrolments, and example attendance/assignment/quiz/event/notice records. The faculty and student demo password is `Campus@123`; their emails are listed in `DATABASE/README.md`.

On the configured development computer, the administrator email is `admin@campus.com`. Its generated password is kept in the private `local-admin.txt` file in the project root. Do not include that file or real credentials in a report or public submission. Change demo passwords before sharing the application.

## 8. Work completed and verification status

The source, schema and sample data were assembled; the local MySQL connection was configured; the project database and sample records were created; an administrator account was initialized; and the Windows app image was built.

The verification notes in `TESTING/TEST_RESULTS.md` report that compilation and packaging succeeded, the configured JDBC connection found all 15 tables, all three sample roles authenticated and an unknown user was rejected, and the packaged app/JAR could locate configuration and connect when launched outside the project directory. Password hash fixture checks also passed.

The full faculty/student GUI workflow was **not** tested end to end for every module. The login UI's visible appearance was also not fully checked. Treat the existing pass results as setup/build/authentication checks, not proof that every button and data workflow is defect-free.

## 9. Current gaps and good next improvements

### First, make it easier to operate

1. Replace attendance's one-popup-per-student process with a roster table and bulk save.
2. Replace modal input dialogs with proper forms, date/time pickers, validation messages and confirmation for sensitive actions.
3. Add a course-management screen for administrators and workflows to create/deactivate faculty and student accounts.
4. Improve admin tools for password resets, account deactivation and account/course management.

### Expand teaching features

5. Allow quizzes with multiple questions, editable drafts, points per question, and clear result review/export.
6. Add assignment file attachments, edit/delete rules, late-submission status and filters. Current submissions are text only.
7. Add attendance summaries by course/date, percentage reports and CSV export.
8. Allow event/notice editing, expiry, search and filters; external email/SMS/push delivery is not present.

### Improve reliability and security

9. Exercise each module as admin, faculty and student, checking that actions are saved and that one user cannot see another user's private records.
10. Use a least-privilege MySQL account rather than a root account for ordinary app use; keep its password out of source control and installer files.
11. Move long database operations off Swing's UI thread, use transactions consistently, and show useful errors for invalid input or database outages.
12. Add automated tests for authentication, role permissions, validation and database constraints; record the results in `TESTING/TEST_RESULTS.md`.
13. For sharing beyond one computer, provide a proper installer/setup that provisions or documents the database and connection settings. The current app image does not install MySQL or migrate a remote database automatically.

## 10. Useful files

- Source: `src/main/java/campus/` and `src/main/java/campus/ui/`
- Database schema and sample data: `DATABASE/schema.sql`, `DATABASE/sample_data.sql`
- Run instructions: `DOCUMENTS/RUN_GUIDE.md`
- Build and packaging scripts: `build.bat`, `run.bat`, `test-db.bat`, `package.bat`
- Verification record: `TESTING/TEST_RESULTS.md`
- Private local database settings and administrator credentials: `local.properties`, `local-admin.txt` (do not share)
