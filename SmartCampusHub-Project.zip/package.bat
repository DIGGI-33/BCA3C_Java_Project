@echo off
call build.bat
if errorlevel 1 exit /b 1
set "JAVA_BIN="
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\jar.exe" set "JAVA_BIN=%JAVA_HOME%\bin"
if not defined JAVA_BIN for /d %%D in ("%ProgramFiles%\Java\jdk-*") do if exist "%%~D\bin\jar.exe" set "JAVA_BIN=%%~D\bin"
if not defined JAVA_BIN set "JAVA_BIN="
if exist build\package rmdir /s /q build\package
mkdir build\package
if not exist build\tmp mkdir build\tmp
copy /y lib\mysql-connector-j-26.7.0.jar build\package\ >nul
echo Main-Class: campus.Main>build\manifest.mf
echo Class-Path: mysql-connector-j-26.7.0.jar>>build\manifest.mf
if defined JAVA_BIN (
  "%JAVA_BIN%\jar.exe" "-J-Djava.io.tmpdir=%CD%\build\tmp" --create --file build\package\SmartCampusHub.jar --manifest build\manifest.mf -C build\classes campus
) else (
  jar "-J-Djava.io.tmpdir=%CD%\build\tmp" --create --file build\package\SmartCampusHub.jar --manifest build\manifest.mf -C build\classes campus
)
if errorlevel 1 exit /b 1
if not exist dist\release-final mkdir dist\release-final
if exist dist\release-final\SmartCampusHub rmdir /s /q dist\release-final\SmartCampusHub
if defined JAVA_BIN (
  "%JAVA_BIN%\jpackage.exe" --temp build\tmp --type app-image --name SmartCampusHub --input build\package --main-jar SmartCampusHub.jar --main-class campus.Main --dest dist\release-final
) else (
  jpackage --temp build\tmp --type app-image --name SmartCampusHub --input build\package --main-jar SmartCampusHub.jar --main-class campus.Main --dest dist\release-final
)
if errorlevel 1 exit /b 1
echo Windows app image created under dist\release-final\SmartCampusHub

