-- Destructive: run only when you intentionally want a clean project database.
DROP DATABASE IF EXISTS smart_campus_hub;
SOURCE DATABASE/schema.sql;
SOURCE DATABASE/sample_data.sql;
