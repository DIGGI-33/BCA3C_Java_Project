# Database setup

1. Start MySQL 8 and execute `schema.sql` in MySQL Workbench to create the `smart_campus_hub` database and tables.
2. Execute `sample_data.sql` to create the five faculty accounts and subjects below, eight student accounts, course enrolments, and sample attendance, coursework, quizzes, results, events, and notices. Re-running it adds only records that are not already present.
3. Create the first administrator with `run.bat --bootstrap-admin`. It prompts for the admin email and password without echoing the password; it refuses to proceed if an administrator already exists.
4. To update an existing local installation without resetting student/campus records, run `run.bat --setup-faculty`. This preserves course IDs and related records, replaces the old demo faculty accounts, refreshes the five faculty passwords, and assigns all students to the five listed subjects.
5. `reset_database.sql` is destructive. Use it only when you intend to discard the entire project database.

On the configured project copy, `run.bat --setup-local` applies the schema/profile migration and loads the sample data while preserving an existing administrator. Start MySQL first. To launch the ready Windows build, open `dist\release-final\SmartCampusHub\SmartCampusHub.exe`.

## Faculty sign-in

| Faculty | Subject | Email | Password |
|---|---|---|---|
| Tirth Bhadeshiya | 05BC3306 — Programming in Java | `tirthbhadeshiya@gmail.com` | `tirthbhadeshiya001` |
| Sahil Sheth | 05CR0301 — Life Skill 1 (Universal Human Values) | `sahilsheth@gmail.com` | `sahilsheth002` |
| Sanket Jethava | 05BC3301 — Database Management System-2 | `sanketjethava@gmail.com` | `sanketjethava003` |
| Jitesh Solanki | 05BC3302 — Data Structure Using C | `jiteshsolanki@gmail.com` | `jiteshsolanki004` |
| Shailja Palsra | 05BC3304 — Management Information System (MIS) | `shailjapalsra@gmail.com` | `shailjapalsra005` |

The faculty passwords follow the requested name-plus-sequence format. Passwords are stored in the database as salted PBKDF2 hashes. Change them to private passwords before using this classroom demo with real accounts.

## Student and administrator sign-in

Student sample accounts use `Campus@123`. Each sample address is based on the student name:

| Student | Email |
|---|---|
| DIGVIJAYSINH | `digvijaysinh@gmail.com` |
| Rohan Desai | `rohandesai@gmail.com` |
| Diya Ambaliya | `diyambaliya@gmail.com` |
| Ishaan Mehta | `ishaanmehta@gmail.com` |
| Nisha Parmar | `nishaparmar@gmail.com` |
| Vivaan Shah | `vivaanshah@gmail.com` |
| Anaya Patel | `anayapatel@gmail.com` |
| Reyansh Joshi | `reyanshjoshi@gmail.com` |

On this configured machine the administrator email is `admin@campus.com`; its generated password is in the private, git-ignored `local-admin.txt` file.

## Profile details

Profiles include optional phone and role-specific details. Faculty can fill in their designation, department, office location, and student consultation hours. Students can fill in program, semester, batch, and section. These values start blank when no verified personal information was provided; each user can add or update them under **My Profile**. A current password is required to save profile changes. The profile screen does not publish these details to other users.
