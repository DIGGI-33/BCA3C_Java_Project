package campus;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/** Applies and verifies the requested display-name change on the local demo account. */
public final class UpdateDemoStudentName {
    public static void main(String[] args) throws Exception {
        try (Connection c = Database.connect();
             PreparedStatement update = c.prepareStatement(
                     "UPDATE users SET full_name=? WHERE email=? AND role=?")) {
            update.setString(1, "DIGVIJAYSINH");
            update.setString(2, "digvijaysinh@gmail.com");
            update.setString(3, "STUDENT");
            if (update.executeUpdate() != 1) {
                throw new IllegalStateException("Expected one matching demo Student account.");
            }
        }
        try (Connection c = Database.connect();
             PreparedStatement query = c.prepareStatement(
                     "SELECT full_name FROM users WHERE email=? AND role=?")) {
            query.setString(1, "digvijaysinh@gmail.com");
            query.setString(2, "STUDENT");
            try (ResultSet r = query.executeQuery()) {
                if (!r.next() || !"DIGVIJAYSINH".equals(r.getString(1))) {
                    throw new IllegalStateException("Display-name verification failed.");
                }
            }
        }
        System.out.println("PASS: Student demo account now displays DIGVIJAYSINH.");
    }
}
