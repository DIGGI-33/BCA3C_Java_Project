package campus;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Rollback-only persistence and constraint checks for the core campus workflows. */
public final class ModuleWorkflowCheck {
    public static void main(String[] args) throws Exception {
        String tag = UUID.randomUUID().toString().substring(0, 8);
        try (Connection c = Database.connect()) {
            c.setAutoCommit(false);
            try {
                long faculty = id(c, "SELECT id FROM users WHERE email='tirthbhadeshiya@gmail.com' AND role='FACULTY'");
                long student = id(c, "SELECT id FROM users WHERE email='digvijaysinh@gmail.com' AND role='STUDENT'");
                long course = id(c, "SELECT id FROM courses WHERE code='05BC3306' AND faculty_id=" + faculty);

                checkAttendance(c, course, faculty, student);
                checkAssignment(c, course, faculty, student, tag);
                checkQuiz(c, course, faculty, student, tag);
                checkEventsAndNotices(c, faculty, student, tag);

                c.rollback();
                System.out.println("PASS: attendance, assignment/submission/grading, multi-question quiz/scoring/one-attempt, event, notice audience, and read status; all test data rolled back.");
            } catch (Exception e) {
                c.rollback();
                throw e;
            }
        }
    }

    private static void checkAttendance(Connection c, long course, long faculty, long student) throws Exception {
        LocalDate date = LocalDate.now().plusYears(20);
        long session = upsertAttendanceSession(c, course, faculty, date);
        require(upsertAttendanceSession(c, course, faculty, date) == session,
                "attendance session upsert did not return the existing session id");
        int enrolled;
        try (PreparedStatement p = c.prepareStatement("SELECT COUNT(*) FROM enrolments WHERE course_id=?")) {
            p.setLong(1, course); try (ResultSet r = p.executeQuery()) { r.next(); enrolled = r.getInt(1); }
        }
        require(enrolled > 0, "05BC3306 must have enrolled students for attendance test");
        try (PreparedStatement p = c.prepareStatement("INSERT INTO attendance_records(session_id,student_id,status) SELECT ?,student_id,IF(student_id=?,'PRESENT','ABSENT') FROM enrolments WHERE course_id=?")) {
            p.setLong(1, session); p.setLong(2, student); p.setLong(3, course); p.executeUpdate();
        }
        try (PreparedStatement p = c.prepareStatement("SELECT COUNT(*),SUM(student_id=? AND status='PRESENT') FROM attendance_records WHERE session_id=?")) {
            p.setLong(1, student); p.setLong(2, session); try (ResultSet r = p.executeQuery()) { r.next(); require(r.getInt(1) == enrolled && r.getInt(2) == 1, "attendance roster did not persist all expected statuses"); }
        }
    }

    private static long upsertAttendanceSession(Connection c, long course, long faculty, LocalDate date) throws Exception {
        try (PreparedStatement p = c.prepareStatement("INSERT INTO attendance_sessions(course_id,session_date,created_by) VALUES(?,?,?) "
                + "ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id)", Statement.RETURN_GENERATED_KEYS)) {
            p.setLong(1, course); p.setDate(2, Date.valueOf(date)); p.setLong(3, faculty); p.executeUpdate();
            try (ResultSet r = p.getGeneratedKeys()) {
                require(r.next(), "attendance session upsert returned no id");
                return r.getLong(1);
            }
        }
    }

    private static void checkAssignment(Connection c, long course, long faculty, long student, String tag) throws Exception {
        long assignment;
        try (PreparedStatement p = c.prepareStatement("INSERT INTO assignments(course_id,created_by,title,description,due_at) VALUES(?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
            p.setLong(1, course); p.setLong(2, faculty); p.setString(3, "QA assignment " + tag); p.setString(4, "Temporary integration test");
            p.setTimestamp(5, Timestamp.valueOf(LocalDateTime.now().plusDays(3))); p.executeUpdate();
            try (ResultSet r = p.getGeneratedKeys()) { require(r.next(), "assignment insert returned no id"); assignment = r.getLong(1); }
        }
        try (PreparedStatement p = c.prepareStatement("INSERT INTO submissions(assignment_id,student_id,body) SELECT ?,?,? WHERE EXISTS(SELECT 1 FROM assignments a JOIN enrolments e ON e.course_id=a.course_id WHERE a.id=? AND e.student_id=?)")) {
            p.setLong(1, assignment); p.setLong(2, student); p.setString(3, "Temporary student submission"); p.setLong(4, assignment); p.setLong(5, student);
            require(p.executeUpdate() == 1, "enrolled student submission was not accepted");
        }
        try (PreparedStatement p = c.prepareStatement("UPDATE submissions s JOIN assignments a ON a.id=s.assignment_id SET s.marks=?,s.feedback=? WHERE s.assignment_id=? AND s.student_id=? AND a.created_by=?")) {
            p.setDouble(1, 92); p.setString(2, "Integration test feedback"); p.setLong(3, assignment); p.setLong(4, student); p.setLong(5, faculty);
            require(p.executeUpdate() == 1, "faculty grading update failed");
        }
        try (PreparedStatement p = c.prepareStatement("SELECT marks,feedback FROM submissions WHERE assignment_id=? AND student_id=?")) {
            p.setLong(1, assignment); p.setLong(2, student); try (ResultSet r = p.executeQuery()) { require(r.next() && r.getDouble(1) == 92 && r.getString(2).contains("Integration test"), "submission marks/feedback did not persist"); }
        }
    }

    private static void checkQuiz(Connection c, long course, long faculty, long student, String tag) throws Exception {
        long quiz;
        try (PreparedStatement p = c.prepareStatement("INSERT INTO quizzes(course_id,created_by,title,instructions) VALUES(?,?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
            p.setLong(1, course); p.setLong(2, faculty); p.setString(3, "QA quiz " + tag); p.setString(4, "Temporary multi-question check"); p.executeUpdate();
            try (ResultSet r = p.getGeneratedKeys()) { require(r.next(), "quiz insert returned no id"); quiz = r.getLong(1); }
        }
        long[] questions = new long[2];
        try (PreparedStatement p = c.prepareStatement("INSERT INTO quiz_questions(quiz_id,prompt,opt_a,opt_b,opt_c,opt_d,correct_option,marks) VALUES(?,?,?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
            questions[0] = addQuestion(p, quiz, "Question one " + tag, "A1", "B1", "C1", "D1", "B", 2);
            questions[1] = addQuestion(p, quiz, "Question two " + tag, "A2", "B2", "C2", "D2", "A", 3);
        }
        try (PreparedStatement p = c.prepareStatement("UPDATE quizzes SET published=TRUE WHERE id=? AND created_by=?")) {
            p.setLong(1, quiz); p.setLong(2, faculty); require(p.executeUpdate() == 1, "quiz did not publish");
        }
        double score = 0;
        String[] chosen = {"B", "A"};
        try (PreparedStatement p = c.prepareStatement("SELECT id,correct_option,marks FROM quiz_questions WHERE quiz_id=? ORDER BY id")) {
            p.setLong(1, quiz); try (ResultSet r = p.executeQuery()) { int i = 0; while (r.next()) { if (chosen[i].equals(r.getString("correct_option"))) score += r.getDouble("marks"); i++; } require(i == 2, "quiz question count is not 2"); }
        }
        require(score == 5.0, "quiz scoring did not calculate expected full score");
        long attempt;
        try (PreparedStatement p = c.prepareStatement("INSERT INTO quiz_attempts(quiz_id,student_id,score) VALUES(?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
            p.setLong(1, quiz); p.setLong(2, student); p.setDouble(3, score); p.executeUpdate(); try (ResultSet r = p.getGeneratedKeys()) { require(r.next(), "quiz attempt returned no id"); attempt = r.getLong(1); }
        }
        try (PreparedStatement p = c.prepareStatement("INSERT INTO quiz_answers(attempt_id,question_id,selected_option) VALUES(?,?,?)")) {
            for (int i = 0; i < 2; i++) { p.setLong(1, attempt); p.setLong(2, questions[i]); p.setString(3, chosen[i]); p.addBatch(); } p.executeBatch();
        }
        try (PreparedStatement p = c.prepareStatement("SELECT score,(SELECT COUNT(*) FROM quiz_answers WHERE attempt_id=?) FROM quiz_attempts WHERE id=?")) {
            p.setLong(1, attempt); p.setLong(2, attempt); try (ResultSet r = p.executeQuery()) { require(r.next() && r.getDouble(1) == 5.0 && r.getInt(2) == 2, "quiz result/answers did not persist"); }
        }
        try (PreparedStatement p = c.prepareStatement("INSERT INTO quiz_attempts(quiz_id,student_id,score) VALUES(?,?,0)")) {
            p.setLong(1, quiz); p.setLong(2, student);
            try { p.executeUpdate(); throw new AssertionError("duplicate quiz attempt was accepted"); }
            catch (SQLIntegrityConstraintViolationException expected) { /* the one-attempt unique constraint worked */ }
        }
    }

    private static long addQuestion(PreparedStatement p, long quiz, String prompt, String a, String b, String c, String d, String correct, double marks) throws Exception {
        p.setLong(1, quiz); p.setString(2, prompt); p.setString(3, a); p.setString(4, b); p.setString(5, c); p.setString(6, d); p.setString(7, correct); p.setDouble(8, marks); p.executeUpdate();
        try (ResultSet r = p.getGeneratedKeys()) { require(r.next(), "question insert returned no id"); return r.getLong(1); }
    }

    private static void checkEventsAndNotices(Connection c, long faculty, long student, String tag) throws Exception {
        long event;
        try (PreparedStatement p = c.prepareStatement("INSERT INTO events(title,description,event_at,location,created_by) VALUES(?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
            p.setString(1, "QA event " + tag); p.setString(2, "Temporary event check"); p.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now().plusDays(2))); p.setString(4, "QA location"); p.setLong(5, faculty); p.executeUpdate();
            try (ResultSet r = p.getGeneratedKeys()) { require(r.next(), "event insert returned no id"); event = r.getLong(1); }
        }
        require(count(c, "SELECT COUNT(*) FROM events WHERE id=? AND event_at>=NOW()", event) == 1, "upcoming event was not visible");
        long notice;
        try (PreparedStatement p = c.prepareStatement("INSERT INTO notifications(title,message,audience,created_by) VALUES(?,?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
            p.setString(1, "QA notice " + tag); p.setString(2, "Temporary audience check"); p.setString(3, "STUDENT"); p.setLong(4, faculty); p.executeUpdate();
            try (ResultSet r = p.getGeneratedKeys()) { require(r.next(), "notice insert returned no id"); notice = r.getLong(1); }
        }
        require(count(c, "SELECT COUNT(*) FROM notifications WHERE id=? AND audience IN ('ALL','STUDENT')", notice) == 1, "student audience could not see notice");
        require(count(c, "SELECT COUNT(*) FROM notifications WHERE id=? AND audience IN ('ALL','FACULTY')", notice) == 0, "faculty audience filter exposed a student-only notice");
        try (PreparedStatement p = c.prepareStatement("INSERT INTO notification_reads(notification_id,user_id) VALUES(?,?)")) {
            p.setLong(1, notice); p.setLong(2, student); p.executeUpdate();
        }
        require(count(c, "SELECT COUNT(*) FROM notification_reads WHERE notification_id=? AND user_id=?", notice, student) == 1, "notice read status did not persist for the user");
    }

    private static long id(Connection c, String sql) throws Exception {
        try (Statement s = c.createStatement(); ResultSet r = s.executeQuery(sql)) {
            if (!r.next()) throw new IllegalStateException("Required demo record is missing.");
            return r.getLong(1);
        }
    }
    private static int count(Connection c, String sql, Object... values) throws Exception {
        try (PreparedStatement p = c.prepareStatement(sql)) {
            for (int i = 0; i < values.length; i++) p.setObject(i + 1, values[i]);
            try (ResultSet r = p.executeQuery()) { r.next(); return r.getInt(1); }
        }
    }
    private static void require(boolean condition, String message) { if (!condition) throw new AssertionError(message); }
}
