package campus;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import campus.ProfileDetails;
import java.util.UUID;

/** Verifies student registration, role assignment, password hashing, and duplicate rejection. */
public final class RegistrationCheck {
    public static void main(String[] args) throws Exception {
        if (!"diyambaliya@gmail.com".equals(Main.suggestedStudentEmail("Diya Ambaliya")))
            throw new AssertionError("Student email suggestion does not follow the requested name-based format.");
        String email = "registration-check-" + UUID.randomUUID() + "@example.test";
        char[] password = "TestAccountPass2026!".toCharArray();
        char[] replacement = "AnotherSecurePass2026!".toCharArray();
        try {
            Main.registerStudent("Registration Check", email, password);
            User user = Main.authenticate(email, password);
            if (user == null || !"STUDENT".equals(user.role())) throw new AssertionError("New account did not authenticate as a student.");
            ProfileDetails details = new ProfileDetails("+1 415-555-0142", null, null, null, null,
                    "BCA", 3, "2024-2027", "C");
            User updated = Main.updateProfile(user, "Updated Registration Check", details, password, replacement);
            if (!"Updated Registration Check".equals(updated.name())) throw new AssertionError("Profile name was not updated.");
            if (!details.equals(Main.loadProfile(updated))) throw new AssertionError("Study and contact details did not round-trip.");
            if (Main.authenticate(email, password) != null || Main.authenticate(email, replacement) == null)
                throw new AssertionError("Password change did not replace the previous password.");
            try {
                Main.registerStudent("Duplicate Check", email, replacement);
                throw new AssertionError("Duplicate email was accepted.");
            } catch (SQLException expected) {
                if (expected.getErrorCode() != 1062) throw expected;
            }
            System.out.println("PASS: student registration, duplicate rejection, profile details save/load, profile name update, password change, and old-password rejection.");
        } finally {
            java.util.Arrays.fill(password, '\0');
            java.util.Arrays.fill(replacement, '\0');
            try (Connection c = Database.connect(); PreparedStatement p = c.prepareStatement("DELETE FROM users WHERE email=? AND role='STUDENT'")) {
                p.setString(1, email);
                p.executeUpdate();
            }
        }
    }
}
