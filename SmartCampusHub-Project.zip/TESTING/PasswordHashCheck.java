package campus;

/** Small offline check for the password format stored by sample_data.sql. */
public final class PasswordHashCheck {
    public static void main(String[] args) {
        String fixture = "pbkdf2$210000$AAECAwQFBgcICQoLDA0ODw==$BIH26F+DbAaYlMZeoWwC9rryx7zCEHdY5F20UZNRAEQ=";
        if (!Security.verify("Campus@123".toCharArray(), fixture)) throw new AssertionError("Sample account password did not verify");
        if (Security.verify("incorrect".toCharArray(), fixture)) throw new AssertionError("Incorrect password unexpectedly verified");
        System.out.println("PASS: fixture password verifies; incorrect password is rejected.");
    }
}
