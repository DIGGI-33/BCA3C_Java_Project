package campus;

import javax.swing.SwingUtilities;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/** Local visual QA harness. Not included in the production package. */
public final class UiPreview {
    public static void main(String[] args) throws Exception {
        String requested = args.length == 0 ? "STUDENT" : args[0].toUpperCase();
        List<String> roles = requested.equals("ALL") ? List.of("STUDENT", "FACULTY", "ADMIN") : List.of(requested);
        List<User> users = new ArrayList<>();
        try (Connection c = Database.connect()) {
            for (String role : roles) {
                if (!role.matches("ADMIN|FACULTY|STUDENT")) throw new IllegalArgumentException("Choose ADMIN, FACULTY, STUDENT, or ALL.");
                try (PreparedStatement p = c.prepareStatement(
                        "SELECT id,full_name,email,role FROM users WHERE role=? AND active=TRUE ORDER BY id LIMIT 1")) {
                    p.setString(1, role);
                    try (ResultSet r = p.executeQuery()) {
                        if (!r.next()) throw new IllegalStateException("No active " + role + " account is available for preview.");
                        users.add(new User(r.getLong(1), r.getString(2), r.getString(3), r.getString(4)));
                    }
                }
            }
        }
        SwingUtilities.invokeLater(() -> users.forEach(user -> new MainFrame(user).setVisible(true)));
    }
}
