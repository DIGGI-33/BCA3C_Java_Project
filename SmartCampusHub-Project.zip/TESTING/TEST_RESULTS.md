# Verification record

Last run: 2026-10-15

## Source build and packaging

- **PASS** — Compiled the application with the installed JDK 26.0.1 and MySQL Connector/J 26.7.0 using `build.bat`.
- **PASS** — Built the final Windows app image with `package.bat` at `dist/release-final/SmartCampusHub`.
- **PASS** — Preserved the earlier package under `dist/SmartCampusHub` while producing the upgraded release image.
- **PASS** — Ran the rebuilt application JAR from `C:\Windows` in `--test-db` mode; it found all 15 tables.
- **PASS** — Ran the rebuilt packaged Windows launcher from `C:\Windows` in `--test-db` mode; it exited successfully.
- **PASS** — `test-db.bat` connected to the configured MySQL service and found 15 tables.

## Authentication and account data checks

- **PASS** — PBKDF2 demo-password fixture accepted `Campus@123`; an incorrect password was rejected.
- **PASS** — Local sign-in check authenticated Admin, Faculty, and Student accounts with the expected database roles; an unknown account was rejected.
- **PASS** — Replaced the two demo faculty accounts with the five requested faculty accounts, authenticated all five with their assigned passwords, verified their five course-code/subject/faculty mappings, and confirmed no other faculty accounts remain.
- **PASS** — Existing Java and DBMS course IDs and student records were preserved while their codes, subjects, and instructors were updated; all active students are enrolled in all five courses.
- **PASS** — Ran the existing-database faculty migration and reran the local sample setup without resetting the administrator or campus database; corrected a semicolon in sample feedback that previously interrupted SQL file loading.
- **PASS** — Integration check created a unique Student account, authenticated it, verified its role, updated the display name and password, rejected the old password, accepted the new password, rejected a duplicate email, and removed its temporary record in a `finally` block.
- **PASS** — Added optional role-specific profile fields and migrated the live database before loading fixture data; verified phone, program, semester, batch, and section save/load using a temporary Student account.
- **PASS** — Applied the expanded idempotent sample data to the live database while preserving the existing administrator; the schema and sample-data setup completed successfully.
- **PASS** — Re-ran registration/profile persistence and rollback-only workflows for attendance, assignments, grading, quizzes, events, and notices against the updated local database.
- **PASS** — Re-verified administrator, all five faculty, and Student login credentials after setup.
- **PASS** — Built the updated runnable JAR and Windows app image; the JAR database check connected successfully and reported 15 application tables.
- **PASS** — Updated the local demo Student account and future sample-data setup to display `DIGVIJAYSINH`; verified the dashboard welcome header and account panel.
- **PASS** — Visually reviewed the Student, Faculty, and Admin dashboard and module screens at runtime: attendance, assignments, quizzes, events/notices, profile, and Admin accounts/courses/enrolments.
- **PASS** — Checked sidebar contrast and labels, dashboard metric spacing, table readability, hidden internal IDs, course selection/enrolment visibility, and role-specific actions.
- **PASS** — Fixed the runtime-discovered attendance save failure by requesting generated keys for the session upsert; the rollback-only integration check now exercises both insert and duplicate-session paths.
- **NOT RUN** — Keyboard-only walkthrough and window-resize QA.
- **NOT RUN** — GUI-driven submit/save actions on every form. Persistence and role checks were run through the rollback-only integration checks, avoiding changes to real campus data.

## Changes covered by compilation

- Branded login view with Student/Faculty/Admin selection, role comparison against the authenticated database account, show/hide password, remember-email preference, Student-only public registration, and transparent administrator-assisted recovery guidance.
- Profile editing with role-specific contact, academic/workplace details, current-password confirmation, and secure password change.
- Role-aware application navigation, styled dashboards and an Admin-only administration screen.
- Attendance roster UI with status editing, bulk present/absent actions, reset-to-saved, transactional save, and course-owner recheck.
- Admin user account creation/deactivation/password reset, course creation/faculty assignment, and student enrolment management.
- Multi-question quiz authoring with per-question marks and transactional quiz creation.
- Shared dashboard metric cards with consistent spacing; role-aware sidebar labels without numeric prefixes and high-contrast navigation states.
- Readable, fixed-width tables with wrapped long text, hidden internal IDs, consistent date/time formatting, and a clearer Admin “Faculty Email” heading.
- Attendance date query, session upsert generated-key handling, event table width, profile card sizing, and first-course enrolment selection fixes.

## Known limitations

- MySQL must be installed/running and reachable; the app image does not bundle a database server. Local DB settings remain in ignored `local.properties`.
- Forgot-password is administrator-assisted. No email delivery or reset-token infrastructure is configured.
- New self-registered students require an administrator to enrol them in a course.
- Assignment submissions are text only. Editing/deletion, file upload, late-submission policy, submission history and filters are not implemented.
- Multi-question quizzes can be created and attempted, but editing questions after creation and richer result analytics are not implemented.
- Event/notice editing, searching, expiry, activity logs, and notification delivery outside the app are not implemented.
- Database operations in several screens still run synchronously on Swing's UI thread and may pause the interface on a slow database.
- The local development database configuration has not been converted to a least-privilege shared deployment account.

No destructive database reset was run during this upgrade. See `DOCUMENTS/BASELINE_AUDIT.md` and `DOCUMENTS/UPGRADE_HANDOFF.md` for architecture and feature details.
