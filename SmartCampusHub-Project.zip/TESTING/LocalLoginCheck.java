package campus;
import java.nio.file.*;
import java.sql.SQLException;

/** Runs sign-in checks against the configured local database without opening the UI. */
public final class LocalLoginCheck {
    public static void main(String[] args) throws Exception {
        String adminPassword=value("Password: ");
        check("admin@campus.com",adminPassword,"ADMIN");
        check("tirthbhadeshiya@gmail.com","tirthbhadeshiya001","FACULTY");
        check("sahilsheth@gmail.com","sahilsheth002","FACULTY");
        check("sanketjethava@gmail.com","sanketjethava003","FACULTY");
        check("jiteshsolanki@gmail.com","jiteshsolanki004","FACULTY");
        check("shailjapalsra@gmail.com","shailjapalsra005","FACULTY");
        check("digvijaysinh@gmail.com","Campus@123","STUDENT");
        check("rohandesai@gmail.com","Campus@123","STUDENT");
        check("diyambaliya@gmail.com","Campus@123","STUDENT");
        check("ishaanmehta@gmail.com","Campus@123","STUDENT");
        check("nishaparmar@gmail.com","Campus@123","STUDENT");
        check("vivaanshah@gmail.com","Campus@123","STUDENT");
        check("anayapatel@gmail.com","Campus@123","STUDENT");
        check("reyanshjoshi@gmail.com","Campus@123","STUDENT");
        if(Main.authenticate("missing@campus.com","wrong".toCharArray())!=null)throw new AssertionError("Unknown user authenticated");
        System.out.println("PASS: admin, all five faculty, all eight name-based student logins; invalid user rejected.");
    }
    private static String value(String prefix)throws Exception{return Files.readAllLines(Path.of("local-admin.txt")).stream().filter(s->s.startsWith(prefix)).map(s->s.substring(prefix.length()).trim()).findFirst().orElseThrow();}
    private static void check(String email,String password,String role)throws SQLException{
        User user=Main.authenticate(email,password.toCharArray());
        if(user==null||!role.equals(user.role()))throw new AssertionError("Login/role check failed for "+email);
    }
}
