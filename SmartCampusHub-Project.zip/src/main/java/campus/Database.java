package campus;

import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.util.Properties;
import java.util.regex.Pattern;

/** Central MySQL configuration and JDBC connection provider. */
public final class Database {
    private static final Properties CONFIG = new Properties();
    static {
        Path p = findConfig();
        if (p != null) try (Reader r = Files.newBufferedReader(p)) { CONFIG.load(r); }
        catch (IOException e) { throw new ExceptionInInitializerError(e); }
    }
    private static Path findConfig() {
        Path cwd=Path.of("").toAbsolutePath().normalize();
        Path found=search(cwd);if(found!=null)return found;
        try {
            Path code=Path.of(Database.class.getProtectionDomain().getCodeSource().getLocation().toURI()).toAbsolutePath().normalize();
            Path dir=Files.isDirectory(code)?code:code.getParent();
            return search(dir);
        } catch(Exception ignored) { return null; }
    }
    private static Path search(Path start) {
        for(Path p=start;p!=null;p=p.getParent()) {
            Path candidate=p.resolve("local.properties");
            if(Files.isRegularFile(candidate))return candidate;
        }
        return null;
    }
    private Database() {}
    public static Connection connect() throws SQLException {
        String url = value("db.url", "jdbc:mysql://localhost:3306/smart_campus_hub?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Kolkata");
        String user = value("db.user", "root");
        String pass = CONFIG.getProperty("db.password", System.getenv().getOrDefault("CAMPUS_DB_PASSWORD", ""));
        try { Class.forName("com.mysql.cj.jdbc.Driver"); }
        catch (ClassNotFoundException e) { throw new SQLException("MySQL Connector/J is missing. Put it in lib and rebuild.", e); }
        return DriverManager.getConnection(url, user, pass);
    }
    private static String value(String k, String fallback) { return CONFIG.getProperty(k, fallback); }
    public static void initializeSchema() throws SQLException, IOException {
        String sql = Files.readString(Path.of("DATABASE", "schema.sql"));
        String url=value("db.url", "jdbc:mysql://localhost:3306/smart_campus_hub?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Kolkata");
        url=url.replaceFirst("/smart_campus_hub(?=\\?|$)", "");
        String pass=CONFIG.getProperty("db.password", System.getenv().getOrDefault("CAMPUS_DB_PASSWORD", ""));
        try { Class.forName("com.mysql.cj.jdbc.Driver"); } catch(ClassNotFoundException e) { throw new SQLException("MySQL Connector/J is missing.",e); }
        try (Connection c=DriverManager.getConnection(url,value("db.user","root"),pass); Statement s = c.createStatement()) {
            for (String part : sql.split(";")) { String q = part.trim(); if (!q.isEmpty()) s.execute(q); }
            // Upgrade existing installations before sample_data.sql refers to profile columns.
            s.execute("USE smart_campus_hub");
            ensureProfileColumns(c);
        }
    }
    public static void loadSampleData() throws SQLException, IOException {
        String sql=Files.readString(Path.of("DATABASE","sample_data.sql"));
        sql=Pattern.compile("(?m)^\\s*--.*$").matcher(sql).replaceAll("");
        try(Connection c=connect();Statement s=c.createStatement()) {
            s.execute("USE smart_campus_hub");
            ensureProfileColumns(c);
            for(String part:sql.split(";")){String q=part.trim();if(!q.isEmpty())try{s.execute(q);}catch(SQLException e){throw new SQLException("Sample data statement failed: "+q,e);}}
        }
    }
    private static void ensureProfileColumns(Connection c) throws SQLException {
        java.util.Map<String,String> columns = new java.util.LinkedHashMap<>();
        columns.put("phone", "VARCHAR(30) NULL");
        columns.put("designation", "VARCHAR(120) NULL");
        columns.put("department", "VARCHAR(120) NULL");
        columns.put("office_location", "VARCHAR(180) NULL");
        columns.put("availability", "VARCHAR(255) NULL");
        columns.put("program", "VARCHAR(120) NULL");
        columns.put("semester", "TINYINT UNSIGNED NULL");
        columns.put("batch", "VARCHAR(30) NULL");
        columns.put("section", "VARCHAR(20) NULL");
        try (PreparedStatement check = c.prepareStatement(
                "SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME=?");
             Statement alter = c.createStatement()) {
            for (var column : columns.entrySet()) {
                check.setString(1, column.getKey());
                try (ResultSet r = check.executeQuery()) {
                    r.next();
                    if (r.getInt(1) == 0) alter.executeUpdate("ALTER TABLE users ADD COLUMN " + column.getKey() + " " + column.getValue());
                }
            }
        }
    }
}
