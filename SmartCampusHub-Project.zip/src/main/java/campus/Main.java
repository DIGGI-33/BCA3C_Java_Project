package campus;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.text.Normalizer;
import java.util.Locale;

public class Main {
    public static void main(String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("--bootstrap-admin")) { bootstrap(); return; }
        if (args.length > 0 && args[0].equalsIgnoreCase("--seed-demo")) { seedDemo(); return; }
        if (args.length > 0 && args[0].equalsIgnoreCase("--setup-local")) { setupLocal(); return; }
        if (args.length > 0 && args[0].equalsIgnoreCase("--setup-faculty")) { setupFaculty(); return; }
        if (args.length > 0 && args[0].equalsIgnoreCase("--test-db")) { testDb(); return; }
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
        catch (Exception ignored) { /* Keep Swing's cross-platform look and feel if Windows styling is unavailable. */ }
        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
    private static void testDb(){try(Connection c=Database.connect();Statement s=c.createStatement();ResultSet r=s.executeQuery("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE()")){r.next();if(r.getInt(1)<12)throw new SQLException("Expected application tables are missing. Run DATABASE/schema.sql.");System.out.println("Database connection passed; "+r.getInt(1)+" tables found.");}catch(Exception e){System.err.println("Database test failed: "+e.getMessage());System.exit(1);}}
    private static void setupFaculty(){try{FacultyRoster.migrateLocalDatabase();System.out.println("Faculty accounts and subject assignments are ready. See DATABASE/README.md for the sign-in details.");}catch(Exception e){System.err.println("Faculty roster setup failed: "+e.getMessage());System.exit(1);}}
    private static void setupLocal(){
        try{
            System.out.println("Preparing project schema...");
            Database.initializeSchema();
            System.out.println("Loading sample records...");
            Database.loadSampleData();
            System.out.println("Checking administrator setup...");
            try(Connection c=Database.connect();Statement s=c.createStatement();ResultSet r=s.executeQuery("SELECT COUNT(*) FROM users WHERE role='ADMIN'")){
                r.next();if(r.getInt(1)>0){System.out.println("Database and sample data ready. An administrator already exists; keeping it unchanged.");return;}
            }
            byte[] bytes=new byte[24];new java.security.SecureRandom().nextBytes(bytes);
            String password=java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
            String email="admin@campus.com";String name="Campus Administrator";String hash=Security.hash(password.toCharArray());
            try(Connection c=Database.connect();PreparedStatement p=c.prepareStatement("INSERT INTO users(full_name,email,password_hash,role) VALUES(?,?,?,'ADMIN')")) {p.setString(1,name);p.setString(2,email);p.setString(3,hash);p.executeUpdate();}
            java.nio.file.Files.writeString(java.nio.file.Path.of("local-admin.txt"),"Smart Campus Hub local administrator\nEmail: "+email+"\nPassword: "+password+"\n\nKeep this file private. Change this password before using the application beyond a local demonstration.\n");
            System.out.println("Setup complete. Administrator credentials were saved to local-admin.txt in this folder.");
            System.out.println("Faculty and student sample accounts use the credentials listed in DATABASE/README.md.");
        }catch(Exception e){System.err.println("Setup failed: "+e.getMessage());e.printStackTrace();System.exit(1);}
    }
    private static void seedDemo(){
        try {
            Database.initializeSchema();
            Database.loadSampleData();
            System.out.println("Demo data ready. The official faculty roster is in DATABASE/README.md; student demo password: Campus@123.");
        } catch(Exception e){System.err.println("Demo data setup failed: "+e.getMessage());}
    }
    static User authenticate(String email, char[] password) throws SQLException {
        String sql="SELECT id,full_name,email,role,password_hash FROM users WHERE LOWER(email)=LOWER(?) AND active=TRUE";
        try(Connection c=Database.connect(); PreparedStatement p=c.prepareStatement(sql)) {
            p.setString(1,email.trim()); try(ResultSet r=p.executeQuery()) {
                if(!r.next()) return null;
                String hash=r.getString("password_hash");
                if(!Security.verify(password,hash)) return null;
                return new User(r.getLong("id"),r.getString("full_name"),r.getString("email"),r.getString("role"));
            }
        }
    }
    static void registerStudent(String name, String email, char[] password) throws SQLException {
        String cleanName = name == null ? "" : name.trim();
        String cleanEmail = email == null ? "" : email.trim().toLowerCase();
        if (cleanName.isBlank() || cleanName.length() > 120) throw new IllegalArgumentException("Enter a name between 1 and 120 characters.");
        if (!cleanEmail.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")) throw new IllegalArgumentException("Enter a valid email address.");
        if (password == null || password.length < 12) throw new IllegalArgumentException("Use a password with at least 12 characters.");
        String hash = Security.hash(password);
        try (Connection c = Database.connect(); PreparedStatement p = c.prepareStatement(
                "INSERT INTO users(full_name,email,password_hash,role) VALUES(?,?,?,'STUDENT')")) {
            p.setString(1, cleanName);
            p.setString(2, cleanEmail);
            p.setString(3, hash);
            p.executeUpdate();
        }
    }

    /** Suggests the requested name-based Gmail address for student account forms. */
    public static String suggestedStudentEmail(String name) {
        String clean = name == null ? "" : Normalizer.normalize(name.trim(), Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        if (clean.isBlank()) return "";
        return clean + "@gmail.com";
    }
    public static ProfileDetails loadProfile(User user) throws SQLException {
        try (Connection c = Database.connect(); PreparedStatement p = c.prepareStatement(
                "SELECT phone,designation,department,office_location,availability,program,semester,batch,section FROM users WHERE id=? AND active=TRUE AND role=?")) {
            p.setLong(1, user.id()); p.setString(2, user.role());
            try (ResultSet r = p.executeQuery()) {
                if (!r.next()) throw new SQLException("This account is unavailable.");
                int semester = r.getInt("semester"); Integer sem = r.wasNull() ? null : semester;
                return new ProfileDetails(r.getString("phone"), r.getString("designation"), r.getString("department"),
                        r.getString("office_location"), r.getString("availability"), r.getString("program"), sem,
                        r.getString("batch"), r.getString("section"));
            }
        }
    }

    public static User updateProfile(User user, String name, char[] currentPassword, char[] newPassword) throws SQLException {
        return updateProfile(user, name, loadProfile(user), currentPassword, newPassword);
    }

    public static User updateProfile(User user, String name, ProfileDetails details, char[] currentPassword, char[] newPassword) throws SQLException {
        String cleanName = name == null ? "" : name.trim();
        if (cleanName.isBlank() || cleanName.length() > 120) throw new IllegalArgumentException("Enter a name between 1 and 120 characters.");
        if (currentPassword == null || currentPassword.length == 0) throw new IllegalArgumentException("Enter your current password to confirm this change.");
        if (details == null) throw new IllegalArgumentException("Profile details are missing.");
        String phone = clean(details.phone());
        if (phone != null && (phone.length() > 30 || !phone.matches("[+0-9().\\-\\s]{7,30}")))
            throw new IllegalArgumentException("Enter a valid phone number using digits, spaces, +, (), . or -.");
        Integer semester = details.semester();
        if (semester != null && (semester < 1 || semester > 12)) throw new IllegalArgumentException("Semester must be between 1 and 12.");
        if (user.role().equals("STUDENT") && semester != null && (details.program() == null || details.program().isBlank()))
            throw new IllegalArgumentException("Enter the program/course when a semester is provided.");
        try (Connection c = Database.connect();
             PreparedStatement check = c.prepareStatement("SELECT password_hash FROM users WHERE id=? AND active=TRUE AND role=?")) {
            check.setLong(1, user.id());
            check.setString(2, user.role());
            try (ResultSet r = check.executeQuery()) {
                if (!r.next() || !Security.verify(currentPassword, r.getString(1))) throw new IllegalArgumentException("Your current password is incorrect.");
            }
            boolean changePassword = newPassword != null && newPassword.length > 0;
            if (changePassword && newPassword.length < 12) throw new IllegalArgumentException("A new password must contain at least 12 characters.");
            String sql = "UPDATE users SET full_name=?,phone=?,designation=?,department=?,office_location=?,availability=?,program=?,semester=?,batch=?,section=?"
                    + (changePassword ? ",password_hash=?" : "") + " WHERE id=? AND role=?";
            try (PreparedStatement update = c.prepareStatement(sql)) {
                int i = 1;
                update.setString(i++, cleanName); update.setString(i++, phone);
                update.setString(i++, clean(details.designation())); update.setString(i++, clean(details.department()));
                update.setString(i++, clean(details.officeLocation())); update.setString(i++, clean(details.availability()));
                update.setString(i++, clean(details.program()));
                if (semester == null) update.setNull(i++, Types.TINYINT); else update.setInt(i++, semester);
                update.setString(i++, clean(details.batch())); update.setString(i++, clean(details.section()));
                if (changePassword) {
                    update.setString(i++, Security.hash(newPassword));
                }
                update.setLong(i++, user.id()); update.setString(i, user.role());
                if (update.executeUpdate() != 1) throw new SQLException("Your profile could not be updated.");
            }
        }
        return new User(user.id(), cleanName, user.email(), user.role());
    }
    private static String clean(String value) { return value == null || value.isBlank() ? null : value.trim(); }
    private static void bootstrap() {
        java.io.Console con=System.console();
        if(con==null){System.err.println("Run this command in a real terminal so the password can be entered without echo.");return;}
        try {
            Database.initializeSchema();
            String email=con.readLine("Initial admin email: ").trim().toLowerCase(); String name=con.readLine("Display name: "); char[] pw=con.readPassword("Initial admin password (12+ characters): ");
            if(!email.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")||pw.length<12) throw new IllegalArgumentException("Enter a valid email and a password of at least 12 characters.");
            String hash=Security.hash(pw); java.util.Arrays.fill(pw,'\0');
            try(Connection c=Database.connect()) { c.setAutoCommit(false);try(PreparedStatement lock=c.prepareStatement("SELECT admin_bootstrapped FROM setup_control WHERE singleton_id=1 FOR UPDATE");ResultSet r=lock.executeQuery()){if(!r.next()||r.getBoolean(1))throw new IllegalStateException("Administrator bootstrap is disabled: an initial admin already exists.");}try(Statement s=c.createStatement();ResultSet r=s.executeQuery("SELECT COUNT(*) FROM users WHERE role='ADMIN'")){r.next();if(r.getInt(1)>0)throw new IllegalStateException("An administrator already exists. Bootstrap is disabled.");}try(PreparedStatement p=c.prepareStatement("INSERT INTO users(full_name,email,password_hash,role) VALUES(?,?,?,'ADMIN')")){p.setString(1,name);p.setString(2,email);p.setString(3,hash);p.executeUpdate();}try(PreparedStatement p=c.prepareStatement("UPDATE setup_control SET admin_bootstrapped=TRUE WHERE singleton_id=1")){p.executeUpdate();}c.commit(); }
            System.out.println("Initial administrator created. Bootstrap is now permanently disabled.");
        } catch(Exception e){System.err.println("Admin setup failed: "+e.getMessage());}
    }
}
