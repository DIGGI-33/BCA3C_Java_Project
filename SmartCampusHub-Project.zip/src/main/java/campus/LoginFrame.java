package campus;

import campus.ui.Ui;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.prefs.Preferences;

final class LoginFrame extends JFrame {
    private final JTextField email = new JTextField(22);
    private final JPasswordField password = new JPasswordField(22);
    private final JComboBox<String> role = new JComboBox<>(new String[]{"Student", "Faculty", "Admin"});
    private final JCheckBox remember = new JCheckBox("Remember email on this computer");
    private final Preferences prefs = Preferences.userNodeForPackage(LoginFrame.class);

    LoginFrame() {
        setTitle("Smart Campus Hub | Sign in");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(900, 590));
        setSize(1040, 650);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(1, 2));
        add(brandPanel());
        add(loginPanel());
        email.setText(prefs.get("rememberedEmail", ""));
        remember.setSelected(!email.getText().isBlank());
        role.setSelectedItem(prefs.get("rememberedRole", "Student"));
        SwingUtilities.invokeLater(email::requestFocusInWindow);
    }

    private JPanel brandPanel() {
        JPanel panel = new JPanel(new GridBagLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(28, 53, 96));
                g2.fillOval(getWidth() - 210, getHeight() - 230, 320, 320);
                g2.setColor(new Color(255, 255, 255, 18));
                g2.fillOval(getWidth() - 155, getHeight() - 178, 210, 210);
                g2.dispose();
            }
        };
        panel.setBackground(Ui.NAVY);
        JPanel content = new JPanel();
        content.setOpaque(false);
        content.setBorder(new EmptyBorder(40, 44, 40, 34));
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        JLabel mark = new JLabel("SMART CAMPUS HUB");
        mark.setFont(new Font("Segoe UI", Font.BOLD, 21));
        mark.setForeground(Color.WHITE);
        JLabel overline = new JLabel("STUDENT LIFE OS");
        overline.setFont(new Font("Segoe UI", Font.BOLD, 11));
        overline.setForeground(new Color(223, 184, 111));
        JLabel headline = new JLabel("<html>Your campus.<br>One connected experience.</html>");
        headline.setFont(new Font("Segoe UI", Font.BOLD, 29));
        headline.setForeground(Color.WHITE);
        JLabel description = new JLabel("<html>One calm place to stay on top of your courses,<br>campus activity and day-to-day student life.</html>");
        description.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        description.setForeground(new Color(204, 216, 235));
        content.add(mark);
        content.add(Box.createVerticalStrut(7));
        content.add(overline);
        content.add(Box.createVerticalGlue());
        content.add(headline);
        content.add(Box.createVerticalStrut(14));
        content.add(description);
        Ui.CampusArtwork artwork = new Ui.CampusArtwork();
        artwork.setPreferredSize(new Dimension(300, 126));
        artwork.setMaximumSize(new Dimension(360, 126));
        artwork.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(Box.createVerticalStrut(5));
        content.add(artwork);
        content.add(Box.createVerticalStrut(9));
        content.add(feature("▤", "Academics", "Assignments and quiz results"));
        content.add(Box.createVerticalStrut(8));
        content.add(feature("◷", "Attendance", "Course-by-course records"));
        content.add(Box.createVerticalStrut(8));
        content.add(feature("✦", "Campus life", "Events and notices together"));
        content.add(Box.createVerticalGlue());
        JLabel footer = new JLabel("SMART CAMPUS HUB  /  LOCAL APP");
        footer.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        footer.setForeground(new Color(174, 190, 214));
        content.add(footer);
        panel.add(content);
        return panel;
    }

    private JPanel feature(String glyph, String title, String sub) {
        JPanel row = new JPanel(new BorderLayout(13, 0));
        row.setOpaque(false);
        JLabel badge = new JLabel(glyph, SwingConstants.CENTER);
        badge.setPreferredSize(new Dimension(36, 36));
        badge.setForeground(new Color(150, 225, 210));
        badge.setFont(new Font("Segoe UI Symbol", Font.BOLD, 15));
        badge.setOpaque(true);
        badge.setBackground(new Color(255,255,255,18));
        badge.setBorder(BorderFactory.createLineBorder(new Color(90, 145, 160)));
        JPanel words = new JPanel();
        words.setOpaque(false);
        words.setLayout(new BoxLayout(words, BoxLayout.Y_AXIS));
        JLabel name = new JLabel(title);
        name.setForeground(Color.WHITE);
        name.setFont(new Font("Segoe UI", Font.BOLD, 14));
        JLabel detail = new JLabel(sub);
        detail.setForeground(new Color(187, 202, 225));
        detail.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        words.add(name);
        words.add(Box.createVerticalStrut(3));
        words.add(detail);
        row.add(badge, BorderLayout.WEST);
        row.add(words, BorderLayout.CENTER);
        row.setAlignmentX(Component.LEFT_ALIGNMENT);
        return row;
    }

    private JPanel loginPanel() {
        JPanel wrap = new JPanel(new GridBagLayout());
        wrap.setBackground(Color.WHITE);
        JPanel form = new JPanel();
        form.setBackground(Color.WHITE);
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setBorder(new EmptyBorder(25, 35, 25, 35));
        form.setPreferredSize(new Dimension(410, 530));
        JLabel eyebrow = new JLabel("CAMPUS ACCOUNT");
        eyebrow.setFont(new Font("Segoe UI", Font.BOLD, 11));
        eyebrow.setForeground(Ui.BLUE);
        JLabel title = new JLabel("Welcome back");
        title.setFont(new Font("Segoe UI", Font.BOLD, 31));
        title.setForeground(Ui.INK);
        JLabel sub = new JLabel("Sign in to continue to your campus.");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        sub.setForeground(Ui.MUTED);
        form.add(eyebrow);
        form.add(Box.createVerticalStrut(7));
        form.add(title);
        form.add(Box.createVerticalStrut(5));
        form.add(sub);
        form.add(Box.createVerticalStrut(25));
        form.add(label("Continue as"));
        styleField(role);
        role.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        form.add(role);
        form.add(Box.createVerticalStrut(17));
        form.add(label("Email address"));
        styleField(email);
        email.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        form.add(email);
        form.add(Box.createVerticalStrut(17));
        form.add(label("Password"));
        styleField(password);
        password.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        form.add(password);
        JCheckBox show = new JCheckBox("Show password");
        show.setBackground(Color.WHITE);
        show.setForeground(Ui.MUTED);
        show.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        show.addActionListener(e -> password.setEchoChar(show.isSelected() ? (char) 0 : '•'));
        form.add(Box.createVerticalStrut(5));
        form.add(show);
        remember.setBackground(Color.WHITE);
        remember.setForeground(Ui.MUTED);
        remember.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        form.add(remember);
        form.add(Box.createVerticalStrut(16));
        JButton signIn = Ui.button("Sign in");
        signIn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        signIn.addActionListener(e -> login());
        form.add(signIn);
        form.add(Box.createVerticalStrut(13));
        JPanel links = new JPanel(new GridLayout(1, 2, 10, 0));
        links.setBackground(Color.WHITE);
        JButton forgot = link("Forgot password?");
        forgot.addActionListener(e -> showRecoveryHelp());
        JButton create = link("Create student account");
        create.addActionListener(e -> register());
        links.add(forgot);
        links.add(create);
        form.add(links);
        form.add(Box.createVerticalGlue());
        JLabel note = new JLabel("Your assigned campus role controls access.");
        note.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        note.setForeground(Ui.MUTED);
        form.add(note);
        wrap.add(form);
        getRootPane().setDefaultButton(signIn);
        return wrap;
    }

    private JLabel label(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label.setForeground(Ui.INK);
        label.setBorder(new EmptyBorder(0, 0, 6, 0));
        return label;
    }

    private void styleField(JComponent field) {
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setForeground(Ui.INK);
        field.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Ui.BORDER),
                new EmptyBorder(7, 10, 7, 10)));
    }

    private JButton link(String text) {
        JButton b = new JButton("<html><u>" + text + "</u></html>");
        b.setBorderPainted(false);
        b.setContentAreaFilled(false);
        b.setForeground(Ui.BLUE);
        b.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    private void login() {
        String em = email.getText().trim();
        char[] pw = password.getPassword();
        if (em.isBlank() || pw.length == 0) {
            JOptionPane.showMessageDialog(this, "Enter both your email and password.", "Sign in", JOptionPane.WARNING_MESSAGE);
            Arrays.fill(pw, '\0');
            return;
        }
        try {
            User user = Main.authenticate(em, pw);
            if (user == null) {
                JOptionPane.showMessageDialog(this, "Email or password is incorrect, or the account is inactive.", "Sign in", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String requestedRole = role.getSelectedItem().toString().toUpperCase();
            if (!user.role().equals(requestedRole)) {
                JOptionPane.showMessageDialog(this, "This account is registered as " + user.role().toLowerCase() + ". Choose that role to continue.", "Role does not match", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (remember.isSelected()) {
                prefs.put("rememberedEmail", em);
                prefs.put("rememberedRole", role.getSelectedItem().toString());
            } else {
                prefs.remove("rememberedEmail");
                prefs.remove("rememberedRole");
            }
            new MainFrame(user).setVisible(true);
            dispose();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Could not connect to the campus database. Start MySQL and check local.properties.\n\nDetails: " + e.getMessage(), "Database connection failed", JOptionPane.ERROR_MESSAGE);
        } finally {
            Arrays.fill(pw, '\0');
        }
    }

    private void showRecoveryHelp() {
        JOptionPane.showMessageDialog(this,
                "Password recovery is handled by an administrator for this local installation.\n\nAsk your campus administrator to verify your identity and set a temporary password. This application has no email delivery or reset-token service configured, so it will not claim to send a reset link.",
                "Password assistance", JOptionPane.INFORMATION_MESSAGE);
    }

    private void register() {
        JTextField name = new JTextField(22);
        JTextField newEmail = new JTextField(22);
        JPasswordField pass = new JPasswordField(22);
        JPasswordField confirm = new JPasswordField(22);
        boolean[] editingEmail = {false};
        boolean[] fillingEmail = {false};
        name.getDocument().addDocumentListener(new DocumentListener() {
            private void update() {
                if (editingEmail[0]) return;
                String suggested = Main.suggestedStudentEmail(name.getText());
                SwingUtilities.invokeLater(() -> {
                    if (!editingEmail[0]) {
                        fillingEmail[0] = true;
                        newEmail.setText(suggested);
                        fillingEmail[0] = false;
                    }
                });
            }
            public void insertUpdate(DocumentEvent e) { update(); }
            public void removeUpdate(DocumentEvent e) { update(); }
            public void changedUpdate(DocumentEvent e) { update(); }
        });
        newEmail.getDocument().addDocumentListener(new DocumentListener() {
            private void edited() { if (!fillingEmail[0] && !newEmail.getText().equals(Main.suggestedStudentEmail(name.getText()))) editingEmail[0] = true; }
            public void insertUpdate(DocumentEvent e) { edited(); }
            public void removeUpdate(DocumentEvent e) { edited(); }
            public void changedUpdate(DocumentEvent e) { edited(); }
        });
        JPanel fields = new JPanel(new GridLayout(0, 1, 5, 5));
        fields.add(new JLabel("Student name")); fields.add(name);
        fields.add(new JLabel("Email address  ·  suggested from your name")); fields.add(newEmail);
        fields.add(new JLabel("Password (at least 12 characters)")); fields.add(pass);
        fields.add(new JLabel("Confirm password")); fields.add(confirm);
        int choice = JOptionPane.showConfirmDialog(this, fields, "Create student account", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        char[] passwordValue = pass.getPassword();
        char[] confirmValue = confirm.getPassword();
        try {
            if (choice != JOptionPane.OK_OPTION) return;
            if (!Arrays.equals(passwordValue, confirmValue)) {
                JOptionPane.showMessageDialog(this, "The passwords do not match.", "Registration", JOptionPane.WARNING_MESSAGE);
                return;
            }
            Main.registerStudent(name.getText(), newEmail.getText(), passwordValue);
            email.setText(newEmail.getText().trim());
            role.setSelectedItem("Student");
            JOptionPane.showMessageDialog(this, "Student account created. You can now sign in.", "Registration complete", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            String message = e.getErrorCode() == 1062 ? "An account already uses that email address." : "Could not create the account: " + e.getMessage();
            JOptionPane.showMessageDialog(this, message, "Registration failed", JOptionPane.ERROR_MESSAGE);
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Check your details", JOptionPane.WARNING_MESSAGE);
        } finally {
            Arrays.fill(passwordValue, '\0');
            Arrays.fill(confirmValue, '\0');
        }
    }
}
