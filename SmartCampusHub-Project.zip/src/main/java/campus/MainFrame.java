package campus;

import campus.ui.*;
import javax.swing.*;
import javax.swing.plaf.basic.BasicButtonUI;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Map;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

final class MainFrame extends JFrame {
    private final User user;
    private final JPanel content = new JPanel(new BorderLayout());
    private final JPanel sidebar = new JPanel();
    private final JLabel pageTitle = new JLabel("Dashboard");
    private final Map<String, JButton> navButtons = new LinkedHashMap<>();
    private String current = "Dashboard";

    MainFrame(User user) {
        this.user = user;
        setTitle("Smart Campus Hub | " + user.role());
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1040, 680));
        setSize(1380, 900);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new BorderLayout());
        getContentPane().setBackground(Ui.BG);
        getContentPane().add(buildSidebar(), BorderLayout.WEST);
        JPanel right = new JPanel(new BorderLayout());
        right.add(buildTopbar(), BorderLayout.NORTH);
        right.add(content, BorderLayout.CENTER);
        content.setBackground(Ui.BG);
        getContentPane().add(right, BorderLayout.CENTER);
        showPanel("Dashboard");
    }

    private JPanel buildSidebar() {
        sidebar.setPreferredSize(new Dimension(245, 0));
        sidebar.setBackground(Ui.NAVY);
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBorder(BorderFactory.createEmptyBorder(22, 13, 18, 13));
        JPanel brand = new JPanel(new BorderLayout(11, 0));
        brand.setOpaque(false);
        JLabel logo = new JLabel("S", SwingConstants.CENTER);
        logo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        logo.setForeground(Color.WHITE);
        logo.setOpaque(true);
        logo.setBackground(Ui.TEAL);
        logo.setPreferredSize(new Dimension(42, 42));
        JPanel wordmark = new JPanel();
        wordmark.setOpaque(false);
        wordmark.setLayout(new BoxLayout(wordmark, BoxLayout.Y_AXIS));
        JLabel brandName = new JLabel("Campus Hub");
        brandName.setForeground(Color.WHITE);
        brandName.setFont(new Font("Segoe UI", Font.BOLD, 17));
        JLabel eyebrow = new JLabel("STUDENT LIFE OS");
        eyebrow.setForeground(new Color(150, 207, 208));
        eyebrow.setFont(new Font("Segoe UI", Font.BOLD, 9));
        wordmark.add(brandName); wordmark.add(Box.createVerticalStrut(3)); wordmark.add(eyebrow);
        brand.setBorder(BorderFactory.createEmptyBorder(8, 6, 22, 2));
        brand.add(logo, BorderLayout.WEST); brand.add(wordmark, BorderLayout.CENTER);
        sidebar.add(brand);
        addNav("Dashboard");
        sidebar.add(Box.createVerticalStrut(8));
        JLabel group = new JLabel("  YOUR CAMPUS");
        group.setForeground(new Color(151, 169, 198));
        group.setFont(new Font("Segoe UI", Font.BOLD, 10));
        group.setBorder(BorderFactory.createEmptyBorder(10, 4, 9, 0));
        sidebar.add(group);
        addNav("Attendance");
        addNav("Assignments");
        addNav("Quizzes & Results");
        addNav("Events & Notices");
        if (user.role().equals("ADMIN")) addNav("Administration");
        addNav("My Profile");
        sidebar.add(Box.createVerticalGlue());
        JPanel userCard = new JPanel(new BorderLayout(10, 0));
        userCard.setOpaque(true);
        userCard.setBackground(new Color(29, 52, 89));
        userCard.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        JLabel avatar = avatar(user.name());
        JLabel name = new JLabel(user.name());
        name.setForeground(Color.WHITE);
        name.setFont(new Font("Segoe UI", Font.BOLD, 13));
        JLabel identity = new JLabel(user.role());
        identity.setForeground(new Color(188, 205, 229));
        identity.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        JPanel profileWords = new JPanel();
        profileWords.setOpaque(false);
        profileWords.setLayout(new BoxLayout(profileWords, BoxLayout.Y_AXIS));
        profileWords.add(name); profileWords.add(Box.createVerticalStrut(4)); profileWords.add(identity);
        userCard.add(avatar, BorderLayout.WEST); userCard.add(profileWords, BorderLayout.CENTER);
        userCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));
        sidebar.add(userCard);
        sidebar.add(Box.createVerticalStrut(9));
        JButton logout = sidebarButton("Sign out", false);
        logout.addActionListener(e -> {
            int answer = JOptionPane.showConfirmDialog(this, "Sign out of Smart Campus Hub?", "Sign out", JOptionPane.YES_NO_OPTION);
            if (answer == JOptionPane.YES_OPTION) {
                dispose();
                new LoginFrame().setVisible(true);
            }
        });
        sidebar.add(logout);
        return sidebar;
    }

    private void addNav(String name) {
        JButton b = sidebarButton(name, false);
        b.addActionListener(e -> showPanel(name));
        navButtons.put(name, b);
        sidebar.add(b);
    }

    private JButton sidebarButton(String text, boolean active) {
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics graphics) {
                Graphics2D g = (Graphics2D) graphics.create();
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                boolean selected = Boolean.TRUE.equals(getClientProperty("nav.active"));
                ButtonModel model = getModel();
                Color fill = selected ? new Color(35, 64, 94)
                        : model.isRollover() ? new Color(27, 48, 77) : Ui.NAVY;
                if ("Sign out".equals(getText()) && model.isRollover()) fill = new Color(91, 48, 61);
                g.setColor(fill);
                g.fillRoundRect(0, 0, getWidth() - 1, getHeight(), 10, 10);
                if (selected) {
                    g.setColor(Ui.GOLD);
                    g.fillRoundRect(0, 9, 3, getHeight() - 18, 3, 3);
                }
                if (hasFocus()) {
                    g.setColor(new Color(223, 184, 111));
                    g.setStroke(new BasicStroke(1.3f));
                    g.drawRoundRect(1, 1, getWidth() - 3, getHeight() - 3, 9, 9);
                }
                g.dispose();
                super.paintComponent(graphics);
            }
        };
        b.setUI(new BasicButtonUI());
        b.putClientProperty("nav.active", active);
        b.setText("   " + Ui.navGlyph(text) + "     " + text);
        b.setHorizontalAlignment(SwingConstants.LEFT);
        b.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        b.setForeground(new Color(199, 211, 229));
        b.setBackground(Ui.NAVY);
        b.setOpaque(false);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createEmptyBorder(11, 10, 11, 8));
        b.setPreferredSize(new Dimension(0, 46));
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    private JPanel buildTopbar() {
        JPanel bar = new JPanel(new BorderLayout(18, 0));
        bar.setBackground(Color.WHITE);
        bar.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Ui.BORDER),
                BorderFactory.createEmptyBorder(14, 30, 14, 28)));
        pageTitle.setFont(new Font("Segoe UI", Font.BOLD, 17));
        pageTitle.setForeground(Ui.INK);
        JPanel session = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        session.setOpaque(false);
        JLabel date = new JLabel(LocalDate.now().format(DateTimeFormatter.ofPattern("EEE, d MMM")));
        date.setForeground(Ui.MUTED); date.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        JLabel avatar = avatar(user.name());
        JLabel who = new JLabel(user.name() + "  ·  " + user.role().toLowerCase());
        who.setForeground(Ui.INK); who.setFont(new Font("Segoe UI", Font.BOLD, 12));
        session.add(date); session.add(Box.createHorizontalStrut(10)); session.add(avatar); session.add(who);
        bar.add(pageTitle, BorderLayout.WEST);
        bar.add(session, BorderLayout.EAST);
        return bar;
    }

    private JLabel avatar(String name) {
        String[] parts = name == null ? new String[0] : name.trim().split("\\s+");
        String initials = parts.length == 0 ? "?" : parts.length == 1 ? parts[0].substring(0, 1)
                : "" + parts[0].charAt(0) + parts[parts.length - 1].charAt(0);
        JLabel badge = new JLabel(initials.toUpperCase(), SwingConstants.CENTER);
        badge.setFont(new Font("Segoe UI", Font.BOLD, 12)); badge.setForeground(new Color(24, 100, 95));
        badge.setOpaque(true); badge.setBackground(new Color(221, 245, 240));
        badge.setPreferredSize(new Dimension(38, 38));
        return badge;
    }

    private void showPanel(String name) {
        current = name;
        pageTitle.setText(name.equals("Events & Notices") ? "Campus Life" : name);
        for (var entry : navButtons.entrySet()) {
            boolean active = entry.getKey().equals(name);
            JButton button = entry.getValue();
            button.putClientProperty("nav.active", active);
            button.setForeground(active ? Color.WHITE : new Color(230, 237, 247));
            button.repaint();
        }
        content.removeAll();
        JPanel panel = switch (name) {
            case "Dashboard" -> new DashboardPanel(user, this::showPanel);
            case "Attendance" -> new AttendancePanel(user);
            case "Assignments" -> new AssignmentPanel(user);
            case "Quizzes & Results" -> new QuizPanel(user);
            case "Administration" -> new AdminPanel(user);
            case "My Profile" -> new ProfilePanel(user, updated -> {
                dispose();
                new MainFrame(updated).setVisible(true);
            });
            default -> new EventPanel(user);
        };
        content.add(Ui.reveal(panel), BorderLayout.CENTER);
        content.revalidate();
        content.repaint();
    }
}
