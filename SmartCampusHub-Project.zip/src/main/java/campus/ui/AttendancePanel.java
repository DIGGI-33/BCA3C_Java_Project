package campus.ui;

import campus.Database;
import campus.User;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public final class AttendancePanel extends JPanel {
    private final User user;
    private final JTable table = Ui.table();

    public AttendancePanel(User user) {
        this.user = user;
        setLayout(new BorderLayout(0, 16));
        setBackground(Ui.BG);
        setBorder(BorderFactory.createEmptyBorder(26, 30, 24, 30));
        JPanel page = Ui.page("Attendance", "Course attendance records and session history");
        JPanel top = new JPanel(new BorderLayout(0, 18));
        top.setBackground(Ui.BG);
        top.add(page.getComponent(0), BorderLayout.NORTH);
        top.add(summaryStrip(), BorderLayout.CENTER);
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        actions.setOpaque(false);
        JButton refresh = Ui.secondaryButton("Refresh records");
        refresh.addActionListener(e -> load());
        actions.add(refresh);
        if (user.role().equals("FACULTY")) {
            JButton mark = Ui.button("Take attendance");
            mark.addActionListener(e -> openRoster());
            actions.add(mark);
        }
        actions.add(Ui.tableTools(table, "Search attendance records"));
        top.add(actions, BorderLayout.SOUTH);
        add(top, BorderLayout.NORTH);
        add(Ui.scroll(table), BorderLayout.CENTER);
        load();
    }

    private JPanel summaryStrip() {
        long total=0,present=0,absent=0;
        String sql="SELECT COUNT(*),COALESCE(SUM(a.status='PRESENT'),0),COALESCE(SUM(a.status='ABSENT'),0) FROM attendance_records a JOIN attendance_sessions s ON s.id=a.session_id JOIN courses c ON c.id=s.course_id";
        if(user.role().equals("STUDENT"))sql+=" WHERE a.student_id=?";
        else if(user.role().equals("FACULTY"))sql+=" WHERE c.faculty_id=?";
        try(Connection c=Database.connect();PreparedStatement p=c.prepareStatement(sql)){
            if(!user.role().equals("ADMIN"))p.setLong(1,user.id());
            try(ResultSet r=p.executeQuery()){if(r.next()){total=r.getLong(1);present=r.getLong(2);absent=r.getLong(3);}}
        }catch(Exception ignored){}
        JPanel strip=new JPanel(new FlowLayout(FlowLayout.LEFT,10,0));strip.setOpaque(false);
        String first=user.role().equals("STUDENT")?"Your attendance":"Saved records";
        String value=user.role().equals("STUDENT")?(total==0?"—":Math.round(100.0*present/total)+"%"):(""+total);
        strip.add(summaryPill(first,value,new Color(35,153,125)));
        strip.add(summaryPill("Present",Long.toString(present),Ui.BLUE));
        strip.add(summaryPill("Absent",Long.toString(absent),new Color(192,88,99)));
        return strip;
    }

    private JPanel summaryPill(String title,String value,Color color){
        JPanel p=Ui.card();p.setLayout(new BorderLayout(12,0));p.setBorder(BorderFactory.createEmptyBorder(9,13,9,13));
        JLabel dot=new JLabel("●");dot.setFont(new Font("Segoe UI",Font.PLAIN,11));dot.setForeground(color);
        JPanel words=new JPanel();words.setOpaque(false);words.setLayout(new BoxLayout(words,BoxLayout.Y_AXIS));
        JLabel k=new JLabel(title);k.setFont(new Font("Segoe UI",Font.PLAIN,10));k.setForeground(Ui.MUTED);
        JLabel v=new JLabel(value);v.setFont(new Font("Segoe UI",Font.BOLD,16));v.setForeground(Ui.INK);
        words.add(k);words.add(v);p.add(dot,BorderLayout.WEST);p.add(words,BorderLayout.CENTER);p.setPreferredSize(new Dimension(190,54));return p;
    }

    private void load() {
        String sql = "SELECT c.code AS Course,s.session_date AS Date,u.full_name AS Student,u.email AS Email,a.status AS Status "
                + "FROM attendance_records a JOIN attendance_sessions s ON s.id=a.session_id "
                + "JOIN courses c ON c.id=s.course_id JOIN users u ON u.id=a.student_id";
        if (user.role().equals("STUDENT")) sql += " WHERE a.student_id=?";
        else if (user.role().equals("FACULTY")) sql += " WHERE c.faculty_id=?";
        sql += " ORDER BY s.session_date DESC,c.code,u.full_name";
        Ui.load(table, sql, user.role().equals("ADMIN") ? new Object[]{} : new Object[]{user.id()});
        Ui.setColumnWidths(table, 100, 140, 210, 380, 100);
    }

    private void openRoster() {
        try (Connection c = Database.connect();
             PreparedStatement p = c.prepareStatement("SELECT id,code,title FROM courses WHERE faculty_id=? ORDER BY code")) {
            p.setLong(1, user.id());
            List<CourseChoice> courses = new ArrayList<>();
            try (ResultSet r = p.executeQuery()) {
                while (r.next()) courses.add(new CourseChoice(r.getLong("id"), r.getString("code"), r.getString("title")));
            }
            if (courses.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No courses are assigned to your account.", "Attendance", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            showRoster(courses);
        } catch (Exception e) {
            Ui.error(this, e);
        }
    }

    private void showRoster(List<CourseChoice> courses) {
        JComboBox<CourseChoice> coursePicker = new JComboBox<>(courses.toArray(CourseChoice[]::new));
        coursePicker.setPreferredSize(new Dimension(390, 36));
        JTextField dateField = new JTextField(LocalDate.now().toString(), 12);
        dateField.setPreferredSize(new Dimension(132, 36));
        JTable roster = Ui.table();
        roster.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 5));
        controls.setBackground(Color.WHITE);
        controls.add(new JLabel("Course"));
        controls.add(coursePicker);
        controls.add(new JLabel("Session date (YYYY-MM-DD)"));
        controls.add(dateField);
        JPanel head = new JPanel(new BorderLayout(0, 8));
        head.setBackground(Color.WHITE);
        head.add(controls, BorderLayout.NORTH);
        JLabel hint = new JLabel("Choose a status for each enrolled student, then save the complete session.");
        hint.setForeground(Ui.MUTED);
        hint.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        hint.setBorder(BorderFactory.createEmptyBorder(0, 4, 3, 4));
        head.add(hint, BorderLayout.SOUTH);
        JPanel body = new JPanel(new BorderLayout(0, 10));
        body.setBackground(Color.WHITE);
        body.add(head, BorderLayout.NORTH);
        body.add(Ui.scroll(roster), BorderLayout.CENTER);
        JButton allPresent = Ui.secondaryButton("Set all present");
        JButton allAbsent = Ui.secondaryButton("Set all absent");
        JButton reset = Ui.secondaryButton("Reset to saved");
        JPanel tools = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        tools.setBackground(Color.WHITE);
        tools.add(allPresent); tools.add(allAbsent); tools.add(reset);
        body.add(tools, BorderLayout.SOUTH);
        Runnable reloadRoster = () -> loadRoster(roster, (CourseChoice) coursePicker.getSelectedItem(), dateField.getText().trim());
        coursePicker.addActionListener(e -> reloadRoster.run());
        dateField.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { reloadRoster.run(); }
            public void removeUpdate(DocumentEvent e) { reloadRoster.run(); }
            public void changedUpdate(DocumentEvent e) { reloadRoster.run(); }
        });
        allPresent.addActionListener(e -> setAll(roster, "PRESENT"));
        allAbsent.addActionListener(e -> setAll(roster, "ABSENT"));
        reset.addActionListener(e -> reloadRoster.run());
        coursePicker.setSelectedIndex(0);
        reloadRoster.run();
        int result = JOptionPane.showConfirmDialog(this, body, "Take course attendance", JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) saveRoster(roster, (CourseChoice) coursePicker.getSelectedItem(), dateField.getText().trim());
    }

    private void loadRoster(JTable roster, CourseChoice course, String date) {
        if (course == null) return;
        LocalDate parsed;
        try { parsed = LocalDate.parse(date); }
        catch (Exception e) { return; }
        String sql = "SELECT u.id,u.full_name,u.email,ar.status FROM enrolments e JOIN users u ON u.id=e.student_id "
                + "LEFT JOIN attendance_sessions s ON s.course_id=e.course_id AND s.session_date=? "
                + "LEFT JOIN attendance_records ar ON ar.session_id=s.id AND ar.student_id=u.id "
                + "WHERE e.course_id=? ORDER BY u.full_name";
        try (Connection c = Database.connect(); PreparedStatement p = c.prepareStatement(sql)) {
            p.setDate(1, Date.valueOf(parsed));
            p.setLong(2, course.id());
            try (ResultSet r = p.executeQuery()) {
                DefaultTableModel model = new DefaultTableModel(new Object[]{"Student ID", "Student", "Email", "Attendance"}, 0) {
                    @Override public boolean isCellEditable(int row, int column) { return column == 3; }
                    @Override public Class<?> getColumnClass(int column) { return column == 0 ? Long.class : String.class; }
                };
                while (r.next()) model.addRow(new Object[]{r.getLong("id"), r.getString("full_name"), r.getString("email"),
                        r.getString("status") == null ? "PRESENT" : r.getString("status")});
                roster.setModel(model);
                roster.getColumnModel().getColumn(0).setMinWidth(0);
                roster.getColumnModel().getColumn(0).setMaxWidth(0);
                roster.getColumnModel().getColumn(0).setPreferredWidth(0);
                roster.getColumnModel().getColumn(3).setCellEditor(new DefaultCellEditor(new JComboBox<>(new String[]{"PRESENT", "ABSENT"})));
                if (model.getRowCount() == 0) JOptionPane.showMessageDialog(this, "There are no students enrolled in this course.", "Attendance", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception e) {
            Ui.error(this, e);
        }
    }

    private void setAll(JTable roster, String status) {
        if (roster.isEditing()) roster.getCellEditor().stopCellEditing();
        for (int i = 0; i < roster.getRowCount(); i++) roster.setValueAt(status, i, 3);
    }

    private void saveRoster(JTable roster, CourseChoice course, String date) {
        if (course == null) return;
        try {
            if (roster.getRowCount() == 0) throw new IllegalArgumentException("There are no enrolled students to mark for this course.");
            LocalDate sessionDate = LocalDate.parse(date);
            if (roster.isEditing()) roster.getCellEditor().stopCellEditing();
            try (Connection c = Database.connect()) {
                c.setAutoCommit(false);
                try (PreparedStatement owner = c.prepareStatement("SELECT id FROM courses WHERE id=? AND faculty_id=? FOR UPDATE")) {
                    owner.setLong(1, course.id());
                    owner.setLong(2, user.id());
                    try (ResultSet check = owner.executeQuery()) {
                        if (!check.next()) throw new SQLException("You no longer have permission to record attendance for this course.");
                    }
                }
                long sessionId;
                try (PreparedStatement p = c.prepareStatement("INSERT INTO attendance_sessions(course_id,session_date,created_by) VALUES(?,?,?) "
                        + "ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id)", Statement.RETURN_GENERATED_KEYS)) {
                    p.setLong(1, course.id());
                    p.setDate(2, Date.valueOf(sessionDate));
                    p.setLong(3, user.id());
                    p.executeUpdate();
                    try (ResultSet keys = p.getGeneratedKeys()) {
                        if (!keys.next()) throw new SQLException("Could not create the attendance session.");
                        sessionId = keys.getLong(1);
                    }
                }
                try (PreparedStatement p = c.prepareStatement("INSERT INTO attendance_records(session_id,student_id,status) VALUES(?,?,?) "
                        + "ON DUPLICATE KEY UPDATE status=VALUES(status)")) {
                    for (int row = 0; row < roster.getRowCount(); row++) {
                        p.setLong(1, sessionId);
                        p.setLong(2, ((Number) roster.getValueAt(row, 0)).longValue());
                        String status = roster.getValueAt(row, 3).toString();
                        if (!status.equals("PRESENT") && !status.equals("ABSENT")) throw new IllegalArgumentException("Choose PRESENT or ABSENT for every student.");
                        p.setString(3, status);
                        p.addBatch();
                    }
                    p.executeBatch();
                }
                c.commit();
            }
            JOptionPane.showMessageDialog(this, "Attendance saved for " + course.code() + " on " + sessionDate + ".", "Attendance saved", JOptionPane.INFORMATION_MESSAGE);
            load();
        } catch (Exception e) {
            Ui.error(this, e);
        }
    }

    private record CourseChoice(long id, String code, String title) {
        @Override public String toString() { return code + " — " + title; }
    }
}
