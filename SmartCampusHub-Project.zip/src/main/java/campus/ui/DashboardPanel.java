package campus.ui;

import campus.Database;
import campus.User;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/** Role-aware dashboard with animated campus artwork, quick links and live activity cards. */
public final class DashboardPanel extends JPanel {
    private final User user;
    private final Consumer<String> navigate;

    public DashboardPanel(User user) { this(user, ignored -> {}); }

    public DashboardPanel(User user, Consumer<String> navigate) {
        this.user = user;
        this.navigate = navigate;
        setLayout(new BorderLayout());
        setBackground(Ui.BG);
        setBorder(new EmptyBorder(22, 28, 22, 28));

        JPanel page = new JPanel();
        page.setOpaque(false);
        page.setLayout(new BoxLayout(page, BoxLayout.Y_AXIS));
        page.add(hero());
        page.add(Box.createVerticalStrut(18));
        JPanel section = new JPanel(new BorderLayout());
        section.setOpaque(false);
        JLabel overview = new JLabel("Your overview");
        overview.setFont(new Font("Segoe UI", Font.BOLD, 17));
        overview.setForeground(Ui.INK);
        JLabel live = new JLabel("A live snapshot of your campus workspace");
        live.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        live.setForeground(Ui.MUTED);
        JPanel words = new JPanel(); words.setOpaque(false); words.setLayout(new BoxLayout(words, BoxLayout.Y_AXIS));
        words.add(overview); words.add(Box.createVerticalStrut(3)); words.add(live);
        section.add(words, BorderLayout.WEST);
        section.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        page.add(section);
        page.add(Box.createVerticalStrut(12));

        JPanel cards = new JPanel(new GridLayout(2, 3, 14, 14));
        cards.setOpaque(false);
        for (Metric metric : metrics(user)) cards.add(metricCard(metric));
        cards.setMaximumSize(new Dimension(Integer.MAX_VALUE, 278));
        cards.setPreferredSize(new Dimension(900, 278));
        page.add(cards);
        page.add(Box.createVerticalStrut(15));
        page.add(activityStrip());
        JScrollPane scroll = new JScrollPane(page);
        scroll.setBorder(null);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.getVerticalScrollBar().setUnitIncrement(18);
        add(scroll, BorderLayout.CENTER);
    }

    private JPanel hero() {
        JPanel hero = new JPanel(new BorderLayout(18, 0)) {
            @Override protected void paintComponent(Graphics graphics) {
                Graphics2D g = (Graphics2D) graphics.create();
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g.setPaint(new GradientPaint(0, 0, new Color(22, 47, 78), getWidth(), getHeight(), new Color(29, 112, 120)));
                g.fillRoundRect(0, 0, getWidth(), getHeight(), 24, 24);
                g.setColor(new Color(255,255,255,16));
                g.fillOval(getWidth()-205, -128, 280, 280);
                g.fillOval(getWidth()-123, 68, 150, 150);
                g.dispose();
                super.paintComponent(graphics);
            }
        };
        hero.setOpaque(false);
        hero.setBorder(new EmptyBorder(22, 26, 18, 22));
        JPanel copy = new JPanel(); copy.setOpaque(false); copy.setLayout(new BoxLayout(copy, BoxLayout.Y_AXIS));
        JLabel date = new JLabel(LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE  ·  d MMMM yyyy")));
        date.setForeground(new Color(180, 225, 222)); date.setFont(new Font("Segoe UI", Font.BOLD, 11));
        JLabel title = new JLabel("Welcome back, " + firstName(user.name()));
        title.setForeground(Color.WHITE); title.setFont(new Font("Segoe UI", Font.BOLD, 27));
        JLabel subtitle = new JLabel(subtitle(user.role()));
        subtitle.setForeground(new Color(221, 234, 244)); subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        JPanel quick = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)); quick.setOpaque(false);
        JButton primary = Ui.button(user.role().equals("STUDENT") ? "View assignments" : "Open attendance");
        primary.setBackground(Ui.GOLD);
        primary.addActionListener(e -> navigate.accept(user.role().equals("STUDENT") ? "Assignments" : "Attendance"));
        JButton events = Ui.secondaryButton("Campus calendar");
        events.addActionListener(e -> navigate.accept("Events & Notices"));
        quick.add(primary); quick.add(events);
        copy.add(date); copy.add(Box.createVerticalStrut(9)); copy.add(title); copy.add(Box.createVerticalStrut(5));
        copy.add(subtitle); copy.add(Box.createVerticalStrut(15)); copy.add(quick);
        Ui.CampusArtwork artwork = new Ui.CampusArtwork();
        artwork.setPreferredSize(new Dimension(240, 160));
        hero.add(copy, BorderLayout.CENTER); hero.add(artwork, BorderLayout.EAST);
        hero.setMaximumSize(new Dimension(Integer.MAX_VALUE, 178));
        hero.setPreferredSize(new Dimension(950, 178));
        return hero;
    }

    private JPanel metricCard(Metric metric) {
        JPanel card = Ui.card();
        card.setLayout(new BorderLayout(0, 8));
        card.setBorder(new EmptyBorder(14, 16, 12, 16));
        JPanel header = new JPanel(new BorderLayout()); header.setOpaque(false);
        JLabel label = new JLabel(metric.label()); label.setFont(new Font("Segoe UI", Font.BOLD, 12)); label.setForeground(Ui.MUTED);
        JLabel icon = new JLabel(Ui.metricGlyph(metric.label()), SwingConstants.CENTER);
        icon.setFont(new Font("Segoe UI Symbol", Font.BOLD, 16)); icon.setForeground(metric.color());
        icon.setOpaque(true); icon.setBackground(new Color(metric.color().getRed(), metric.color().getGreen(), metric.color().getBlue(), 24));
        icon.setPreferredSize(new Dimension(34, 34));
        header.add(label, BorderLayout.WEST); header.add(icon, BorderLayout.EAST);
        JLabel value = new JLabel(query(metric.sql(), metric.userId()));
        value.setFont(new Font("Segoe UI", Font.BOLD, 27)); value.setForeground(Ui.INK);
        JLabel detail = new JLabel(metric.detail()); detail.setFont(new Font("Segoe UI", Font.PLAIN, 11)); detail.setForeground(Ui.MUTED);
        JPanel center = new JPanel(); center.setOpaque(false); center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.add(value); center.add(Box.createVerticalStrut(3)); center.add(detail);
        JPanel stripe = new JPanel(new BorderLayout()); stripe.setOpaque(false);
        JPanel fill = new JPanel(); fill.setBackground(metric.color()); fill.setPreferredSize(new Dimension(44, 3));
        stripe.add(fill, BorderLayout.WEST);
        card.add(header, BorderLayout.NORTH); card.add(center, BorderLayout.CENTER); card.add(stripe, BorderLayout.SOUTH);
        card.setToolTipText(metric.label() + " · " + metric.detail());
        return card;
    }

    private JPanel activityStrip() {
        JPanel strip = new JPanel(new GridLayout(1, 2, 14, 0)); strip.setOpaque(false);
        strip.add(activityCard("Next campus event", upcomingEvent(), Ui.TEAL, "Events & Notices"));
        String secondary = user.role().equals("STUDENT") ? "Assignments and assessments are ready when you are."
                : user.role().equals("FACULTY") ? "Keep course activity moving with attendance and feedback."
                : "Manage accounts, course access and campus activity.";
        strip.add(activityCard("Your next step", secondary, Ui.BLUE,
                user.role().equals("STUDENT") ? "Assignments" : user.role().equals("FACULTY") ? "Attendance" : "Administration"));
        strip.setMaximumSize(new Dimension(Integer.MAX_VALUE, 92));
        return strip;
    }

    private JPanel activityCard(String title, String detail, Color accent, String destination) {
        JPanel card = Ui.card(); card.setBorder(new EmptyBorder(12, 16, 12, 16));
        JPanel words = new JPanel(); words.setOpaque(false); words.setLayout(new BoxLayout(words, BoxLayout.Y_AXIS));
        JLabel heading = new JLabel(title); heading.setFont(new Font("Segoe UI", Font.BOLD, 12)); heading.setForeground(accent);
        JLabel body = new JLabel("<html>" + detail + "</html>"); body.setFont(new Font("Segoe UI", Font.PLAIN, 11)); body.setForeground(Ui.MUTED);
        words.add(heading); words.add(Box.createVerticalStrut(5)); words.add(body);
        JButton open = Ui.secondaryButton("Open  ›"); open.addActionListener(e -> navigate.accept(destination));
        card.add(words, BorderLayout.CENTER); card.add(open, BorderLayout.EAST);
        return card;
    }

    private String upcomingEvent() {
        try (Connection c=Database.connect(); PreparedStatement p=c.prepareStatement(
                "SELECT title,DATE_FORMAT(event_at,'%a, %d %b · %h:%i %p'),location FROM events WHERE event_at>=NOW() ORDER BY event_at LIMIT 1");
             ResultSet r=p.executeQuery()) {
            if (r.next()) return r.getString(1) + " · " + r.getString(2) + " · " + r.getString(3);
        } catch (Exception ignored) { return "Check the campus calendar for the latest event."; }
        return "No upcoming events yet. Check back soon.";
    }

    private String firstName(String name) { return name == null || name.isBlank() ? "there" : name.trim().split("\\s+")[0]; }
    private String subtitle(String role) { return switch(role) {
        case "STUDENT" -> "A fresh look at your classes, progress and campus life.";
        case "FACULTY" -> "Your courses, student work and teaching tools in one place.";
        default -> "An at-a-glance view of your campus community.";
    }; }

    private List<Metric> metrics(User user) {
        long id = user.id();
        List<Metric> result = new ArrayList<>();
        switch (user.role()) {
            case "STUDENT" -> {
                result.add(new Metric("Attendance", "SELECT CONCAT(ROUND(100*COALESCE(AVG(status='PRESENT'),0)),'%') FROM attendance_records WHERE student_id=?", id, "Across recorded sessions", new Color(34, 153, 125)));
                result.add(new Metric("My assignments", "SELECT COUNT(*) FROM assignments a JOIN enrolments e ON e.course_id=a.course_id WHERE e.student_id=? AND a.due_at>=NOW()", id, "Open and upcoming", Ui.BLUE));
                result.add(new Metric("Published quizzes", "SELECT COUNT(*) FROM quizzes q JOIN enrolments e ON e.course_id=q.course_id WHERE e.student_id=? AND q.published=TRUE", id, "In your enrolled courses", new Color(133, 94, 190)));
                result.add(new Metric("Quiz attempts", "SELECT COUNT(*) FROM quiz_attempts WHERE student_id=?", id, "Submitted assessments", new Color(195, 137, 49)));
                result.add(new Metric("Upcoming events", "SELECT COUNT(*) FROM events WHERE event_at>=NOW()", id, "On the campus calendar", new Color(43, 137, 160)));
                result.add(new Metric("Unread notices", "SELECT COUNT(*) FROM notifications n LEFT JOIN notification_reads r ON r.notification_id=n.id AND r.user_id=? WHERE n.audience IN ('ALL','STUDENT') AND r.user_id IS NULL", id, "For students and everyone", new Color(192, 88, 99)));
            }
            case "FACULTY" -> {
                result.add(new Metric("My courses", "SELECT COUNT(*) FROM courses WHERE faculty_id=?", id, "Assigned to you", Ui.BLUE));
                result.add(new Metric("My assignments", "SELECT COUNT(*) FROM assignments WHERE created_by=?", id, "Created for your courses", new Color(133, 94, 190)));
                result.add(new Metric("My quizzes", "SELECT COUNT(*) FROM quizzes WHERE created_by=?", id, "Draft and published", new Color(195, 137, 49)));
                result.add(new Metric("Attendance records", "SELECT COUNT(*) FROM attendance_records r JOIN attendance_sessions s ON s.id=r.session_id JOIN courses c ON c.id=s.course_id WHERE c.faculty_id=?", id, "Across your courses", new Color(34, 153, 125)));
                result.add(new Metric("To review", "SELECT COUNT(*) FROM submissions s JOIN assignments a ON a.id=s.assignment_id WHERE a.created_by=? AND s.marks IS NULL", id, "Submissions without marks", new Color(192, 88, 99)));
                result.add(new Metric("Upcoming events", "SELECT COUNT(*) FROM events WHERE event_at>=NOW()", id, "On the campus calendar", new Color(43, 137, 160)));
            }
            default -> {
                result.add(new Metric("Students", "SELECT COUNT(*) FROM users WHERE role='STUDENT'", id, "Registered accounts", Ui.BLUE));
                result.add(new Metric("Faculty", "SELECT COUNT(*) FROM users WHERE role='FACULTY'", id, "Teaching accounts", new Color(133, 94, 190)));
                result.add(new Metric("Assignments", "SELECT COUNT(*) FROM assignments", id, "Across the campus", new Color(195, 137, 49)));
                result.add(new Metric("Quizzes", "SELECT COUNT(*) FROM quizzes", id, "Created assessments", new Color(34, 153, 125)));
                result.add(new Metric("Attendance records", "SELECT COUNT(*) FROM attendance_records", id, "Saved student records", new Color(43, 137, 160)));
                result.add(new Metric("Upcoming events", "SELECT COUNT(*) FROM events WHERE event_at>=NOW()", id, "On the campus calendar", new Color(192, 88, 99)));
            }
        }
        return result;
    }

    private String query(String sql, long userId) {
        try (Connection c = Database.connect(); PreparedStatement p = c.prepareStatement(sql)) {
            if (sql.contains("?")) p.setLong(1, userId);
            try (ResultSet r = p.executeQuery()) { if (r.next()) return r.getString(1) == null ? "0" : r.getString(1); }
        } catch (Exception ignored) { return "—"; }
        return "0";
    }

    private record Metric(String label, String sql, long userId, String detail, Color color) {}
}
