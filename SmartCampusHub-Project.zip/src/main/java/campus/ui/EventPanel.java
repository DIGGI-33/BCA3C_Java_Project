package campus.ui;

import campus.Database;
import campus.User;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.*;
import java.time.LocalDateTime;

/** Campus calendar and audience-aware notice center. */
public final class EventPanel extends JPanel {
    private final User user;
    private final JTable events = Ui.table();
    private final JTable notices = Ui.table();
    private final JComboBox<String> eventScope = new JComboBox<>(new String[]{"Upcoming", "All events", "Past events"});

    public EventPanel(User user) {
        this.user = user;
        setLayout(new BorderLayout(0, 16));
        setBackground(Ui.BG);
        setBorder(new EmptyBorder(24, 28, 22, 28));
        JPanel page = Ui.page("Campus life", "A calendar and noticeboard for what’s happening around campus");
        JPanel top = new JPanel(new BorderLayout(0, 14)); top.setOpaque(false);
        top.add(page.getComponent(0), BorderLayout.NORTH);
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)); actions.setOpaque(false);
        eventScope.setFont(new Font("Segoe UI", Font.PLAIN, 12)); eventScope.setPreferredSize(new Dimension(140, 38));
        eventScope.addActionListener(e -> loadEvents());
        actions.add(eventScope);
        JButton refresh = Ui.secondaryButton("Refresh"); refresh.addActionListener(e -> load()); actions.add(refresh);
        if (!user.role().equals("STUDENT")) {
            JButton add = Ui.button("＋  Add event"); add.addActionListener(e -> editEvent(null)); actions.add(add);
            JButton edit = Ui.secondaryButton("Edit selected"); edit.addActionListener(e -> editSelected()); actions.add(edit);
            JButton remove = Ui.secondaryButton("Remove selected"); remove.addActionListener(e -> removeSelected()); actions.add(remove);
            JButton notice = Ui.button("Publish notice"); notice.addActionListener(e -> publishNotice()); actions.add(notice);
        }
        JButton markRead = Ui.secondaryButton("Mark selected read"); markRead.addActionListener(e -> markRead()); actions.add(markRead);
        actions.add(Ui.tableTools(events, "Search campus events"));
        top.add(actions, BorderLayout.SOUTH);
        add(top, BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Segoe UI", Font.BOLD, 12));
        JPanel eventTab = new JPanel(new BorderLayout(0, 8)); eventTab.setBackground(Ui.BG);
        JPanel eventHeading = miniHeading("Campus calendar", "Browse upcoming activities, workshops and campus events");
        eventTab.add(eventHeading, BorderLayout.NORTH); eventTab.add(Ui.scroll(events), BorderLayout.CENTER);
        JPanel noticeTab = new JPanel(new BorderLayout(0, 8)); noticeTab.setBackground(Ui.BG);
        noticeTab.add(miniHeading("Notices for you", "Announcements are filtered for your campus role"), BorderLayout.NORTH);
        JPanel noticeControls = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)); noticeControls.setOpaque(false);
        noticeControls.add(Ui.tableTools(notices, "Search campus notices"));
        noticeTab.add(noticeControls, BorderLayout.SOUTH);
        noticeTab.add(Ui.scroll(notices), BorderLayout.CENTER);
        tabs.addTab("Events  ✦", eventTab);
        tabs.addTab("Notices  ◉", noticeTab);
        add(tabs, BorderLayout.CENTER);
        load();
    }

    private JPanel miniHeading(String title, String subtitle) {
        JPanel p = new JPanel(); p.setOpaque(false); p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        JLabel t = new JLabel(title); t.setFont(new Font("Segoe UI", Font.BOLD, 14)); t.setForeground(Ui.INK);
        JLabel s = new JLabel(subtitle); s.setFont(new Font("Segoe UI", Font.PLAIN, 11)); s.setForeground(Ui.MUTED);
        p.add(t); p.add(Box.createVerticalStrut(3)); p.add(s); p.setBorder(new EmptyBorder(2, 2, 4, 2));
        return p;
    }

    private void load() { loadEvents(); loadNotices(); }

    private void loadEvents() {
        String scope = switch (eventScope.getSelectedIndex()) {
            case 1 -> "";
            case 2 -> " WHERE event_at<NOW()";
            default -> " WHERE event_at>=NOW()";
        };
        Ui.load(events, "SELECT id,title Title,description Details,DATE_FORMAT(event_at,'%a, %d %b %Y · %h:%i %p') When,location Location FROM events" + scope + " ORDER BY event_at");
        Ui.setColumnWidths(events, 0, 200, 360, 220, 170);
        Ui.wrapTextColumns(events, 1, 2);
    }

    private void loadNotices() {
        Ui.load(notices, "SELECT n.id,n.title Title,n.message Message,DATE_FORMAT(n.created_at,'%d %b %Y, %h:%i %p') Published,IF(nr.user_id IS NULL,'UNREAD','READ') Status FROM notifications n LEFT JOIN notification_reads nr ON nr.notification_id=n.id AND nr.user_id=? WHERE n.audience IN ('ALL',?) ORDER BY n.created_at DESC", user.id(), user.role());
        Ui.setColumnWidths(notices, 0, 210, 430, 190, 100);
        Ui.wrapTextColumns(notices, 1, 2);
    }

    private void editEvent(Integer eventId) {
        JTextField title = new JTextField(28);
        JTextArea description = new JTextArea(5, 28); description.setLineWrap(true); description.setWrapStyleWord(true);
        JTextField date = new JTextField(LocalDateTime.now().plusDays(7).withHour(14).withMinute(0).withSecond(0).withNano(0).toString().replace('T',' '), 25);
        JTextField location = new JTextField(28);
        if (eventId != null) {
            try (Connection c=Database.connect(); PreparedStatement p=c.prepareStatement("SELECT title,description,event_at,location FROM events WHERE id=? AND (created_by=? OR ?='ADMIN')")) {
                p.setInt(1,eventId); p.setLong(2,user.id()); p.setString(3,user.role());
                try(ResultSet r=p.executeQuery()) { if(!r.next()) throw new SQLException("This event is not available to edit."); title.setText(r.getString(1)); description.setText(r.getString(2)); date.setText(r.getTimestamp(3).toLocalDateTime().toString().replace('T',' ')); location.setText(r.getString(4)); }
            } catch(Exception e) { Ui.error(this,e); return; }
        }
        JPanel form = new JPanel(new GridBagLayout()); form.setBackground(Color.WHITE); form.setBorder(new EmptyBorder(8,8,8,8));
        GridBagConstraints g=new GridBagConstraints(); g.gridx=0;g.gridy=0;g.anchor=GridBagConstraints.WEST;g.fill=GridBagConstraints.HORIZONTAL;g.weightx=1;g.insets=new Insets(4,4,7,4);
        addFormField(form,g,"Event name",title); addFormField(form,g,"What’s happening",new JScrollPane(description));
        addFormField(form,g,"Date and time  ·  YYYY-MM-DD HH:MM:SS",date); addFormField(form,g,"Campus location",location);
        if (JOptionPane.showConfirmDialog(this,form,eventId==null?"Create campus event":"Edit campus event",JOptionPane.OK_CANCEL_OPTION,JOptionPane.PLAIN_MESSAGE)!=JOptionPane.OK_OPTION)return;
        if(title.getText().isBlank()||description.getText().isBlank()||location.getText().isBlank()) { JOptionPane.showMessageDialog(this,"Add an event name, details and location.","Event details",JOptionPane.WARNING_MESSAGE); return; }
        try(Connection c=Database.connect()) {
            if(eventId==null) try(PreparedStatement p=c.prepareStatement("INSERT INTO events(title,description,event_at,location,created_by) VALUES(?,?,?,?,?)")) { p.setString(1,title.getText().trim());p.setString(2,description.getText().trim());p.setTimestamp(3,Timestamp.valueOf(date.getText().trim()));p.setString(4,location.getText().trim());p.setLong(5,user.id());p.executeUpdate(); }
            else try(PreparedStatement p=c.prepareStatement("UPDATE events SET title=?,description=?,event_at=?,location=? WHERE id=? AND (created_by=? OR ?='ADMIN')")) { p.setString(1,title.getText().trim());p.setString(2,description.getText().trim());p.setTimestamp(3,Timestamp.valueOf(date.getText().trim()));p.setString(4,location.getText().trim());p.setInt(5,eventId);p.setLong(6,user.id());p.setString(7,user.role());if(p.executeUpdate()!=1)throw new SQLException("This event could not be updated."); }
            loadEvents();
        } catch(Exception e) { Ui.error(this,e); }
    }

    private void addFormField(JPanel form, GridBagConstraints g, String label, Component input) {
        JLabel l=new JLabel(label);l.setFont(new Font("Segoe UI",Font.BOLD,12));l.setForeground(Ui.INK);
        g.gridy++;form.add(l,g);g.gridy++;input.setFont(new Font("Segoe UI",Font.PLAIN,13));form.add(input,g);
    }

    private void editSelected() { int row=events.getSelectedRow();if(row<0){JOptionPane.showMessageDialog(this,"Select an event first.");return;}editEvent(Integer.parseInt(events.getValueAt(row,0).toString())); }

    private void removeSelected() {
        int row=events.getSelectedRow();if(row<0){JOptionPane.showMessageDialog(this,"Select an event first.");return;}
        if(JOptionPane.showConfirmDialog(this,"Remove this campus event?","Remove event",JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION)return;
        try(Connection c=Database.connect();PreparedStatement p=c.prepareStatement("DELETE FROM events WHERE id=? AND (created_by=? OR ?='ADMIN')")) {
            p.setInt(1,Integer.parseInt(events.getValueAt(row,0).toString()));p.setLong(2,user.id());p.setString(3,user.role());if(p.executeUpdate()!=1)throw new SQLException("This event is not available to remove.");loadEvents();
        } catch(Exception e) { Ui.error(this,e); }
    }

    private void publishNotice() {
        JTextField title=new JTextField(28);JTextArea message=new JTextArea(5,28);message.setLineWrap(true);message.setWrapStyleWord(true);
        JComboBox<String> audience=new JComboBox<>(new String[]{"ALL","STUDENT","FACULTY"});
        JPanel form=new JPanel(new GridLayout(0,1,5,5));form.add(new JLabel("Notice title"));form.add(title);form.add(new JLabel("Message"));form.add(new JScrollPane(message));form.add(new JLabel("Audience"));form.add(audience);
        if(JOptionPane.showConfirmDialog(this,form,"Publish campus notice",JOptionPane.OK_CANCEL_OPTION,JOptionPane.PLAIN_MESSAGE)!=JOptionPane.OK_OPTION)return;
        if(title.getText().isBlank()||message.getText().isBlank()){JOptionPane.showMessageDialog(this,"Enter both a title and a message.");return;}
        try(Connection c=Database.connect();PreparedStatement p=c.prepareStatement("INSERT INTO notifications(title,message,audience,created_by) VALUES(?,?,?,?)")) {
            p.setString(1,title.getText().trim());p.setString(2,message.getText().trim());p.setString(3,audience.getSelectedItem().toString());p.setLong(4,user.id());p.executeUpdate();loadNotices();
        } catch(Exception e) { Ui.error(this,e); }
    }

    private void markRead() {
        int row=notices.getSelectedRow();if(row<0){JOptionPane.showMessageDialog(this,"Select a notice first.");return;}
        try(Connection c=Database.connect();PreparedStatement p=c.prepareStatement("INSERT IGNORE INTO notification_reads(notification_id,user_id) VALUES(?,?)")) {p.setLong(1,Long.parseLong(notices.getValueAt(row,0).toString()));p.setLong(2,user.id());p.executeUpdate();loadNotices();}
        catch(Exception e){Ui.error(this,e);}
    }
}
