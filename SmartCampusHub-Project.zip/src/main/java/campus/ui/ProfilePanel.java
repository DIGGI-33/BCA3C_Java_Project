package campus.ui;

import campus.Main;
import campus.ProfileDetails;
import campus.User;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.Arrays;
import java.util.function.Consumer;

public final class ProfilePanel extends JPanel {
    private final User user;
    private final Consumer<User> onUpdated;
    private final JTextField name = new JTextField(28);
    private final JTextField phone = new JTextField(28);
    private final JTextField designation = new JTextField(28);
    private final JTextField department = new JTextField(28);
    private final JTextField officeLocation = new JTextField(28);
    private final JTextField availability = new JTextField(28);
    private final JTextField program = new JTextField(28);
    private final JTextField semester = new JTextField(28);
    private final JTextField batch = new JTextField(28);
    private final JTextField section = new JTextField(28);
    private final JPasswordField currentPassword = new JPasswordField(28);
    private final JPasswordField newPassword = new JPasswordField(28);
    private final JPasswordField confirmPassword = new JPasswordField(28);

    public ProfilePanel(User user, Consumer<User> onUpdated) {
        this.user = user;
        this.onUpdated = onUpdated;
        setLayout(new BorderLayout(0, 20));
        setBackground(Ui.BG);
        setBorder(new EmptyBorder(26, 30, 24, 30));
        JPanel header = Ui.page("My profile", "Manage the details and password for your campus account");
        add(header.getComponent(0), BorderLayout.NORTH);
        JPanel content = new JPanel();
        content.setBackground(Color.WHITE);
        content.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Ui.BORDER),
                BorderFactory.createEmptyBorder(22, 26, 24, 26)));
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        ProfileDetails details;
        try { details = Main.loadProfile(user); }
        catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Your profile details could not be loaded: " + e.getMessage(), "Profile", JOptionPane.WARNING_MESSAGE);
            details = new ProfileDetails(null, null, null, null, null, null, null, null, null);
        }
        name.setText(user.name());
        phone.setText(value(details.phone()));
        designation.setText(value(details.designation()));
        department.setText(value(details.department()));
        officeLocation.setText(value(details.officeLocation()));
        availability.setText(value(details.availability()));
        program.setText(value(details.program()));
        semester.setText(details.semester() == null ? "" : details.semester().toString());
        batch.setText(value(details.batch()));
        section.setText(value(details.section()));
        sectionHeader(content, "Account");
        addField(content, "Display name", name);
        JTextField email = new JTextField(user.email());
        email.setEditable(false);
        style(email);
        addField(content, "Email address", email);
        JTextField role = new JTextField(user.role());
        role.setEditable(false);
        style(role);
        addField(content, "Campus role", role);
        sectionHeader(content, "Contact and campus details");
        addField(content, "Personal phone number (optional)", phone);
        if (user.role().equals("FACULTY")) {
            addField(content, "Designation", designation);
            addField(content, "Department / program", department);
            addField(content, "Office location (building and room)", officeLocation);
            addField(content, "Availability / student consultation hours", availability);
        } else if (user.role().equals("STUDENT")) {
            addField(content, "Program / course", program);
            addField(content, "Semester (1–12)", semester);
            addField(content, "Batch / academic years", batch);
            addField(content, "Section", section);
        } else {
            addField(content, "Designation", designation);
            addField(content, "Department", department);
            addField(content, "Office location", officeLocation);
        }
        JLabel privacy = new JLabel("Only your account profile uses these contact and study/work details.");
        privacy.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        privacy.setForeground(Ui.MUTED);
        privacy.setAlignmentX(Component.LEFT_ALIGNMENT);
        privacy.setBorder(new EmptyBorder(0, 0, 6, 0));
        content.add(privacy);
        sectionHeader(content, "Password and security");
        JLabel security = new JLabel("Change password (leave new password fields empty to keep the current password)");
        security.setFont(new Font("Segoe UI", Font.BOLD, 14));
        security.setForeground(Ui.INK);
        security.setBorder(new EmptyBorder(18, 0, 8, 0));
        security.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(security);
        addField(content, "Current password (required to save)", currentPassword);
        addField(content, "New password (at least 12 characters)", newPassword);
        addField(content, "Confirm new password", confirmPassword);
        JButton save = Ui.button("Save profile");
        save.setAlignmentX(Component.LEFT_ALIGNMENT);
        save.addActionListener(e -> save());
        content.add(Box.createVerticalStrut(12));
        content.add(save);
        content.setPreferredSize(new Dimension(850, content.getPreferredSize().height));
        content.setMaximumSize(new Dimension(850, Integer.MAX_VALUE));
        JPanel holder = new JPanel(new GridBagLayout());
        holder.setOpaque(false);
        GridBagConstraints cardConstraints = new GridBagConstraints();
        cardConstraints.gridx = 0;
        cardConstraints.gridy = 0;
        cardConstraints.weightx = 1;
        cardConstraints.weighty = 1;
        cardConstraints.fill = GridBagConstraints.HORIZONTAL;
        cardConstraints.anchor = GridBagConstraints.NORTH;
        holder.add(content, cardConstraints);
        JScrollPane scroll = new JScrollPane(holder);
        scroll.setBorder(null);
        scroll.getViewport().setOpaque(false);
        scroll.getVerticalScrollBar().setUnitIncrement(18);
        add(scroll, BorderLayout.CENTER);
    }

    private static String value(String text) { return text == null ? "" : text; }

    private void sectionHeader(JPanel parent, String title) {
        JLabel label = new JLabel(title);
        label.setFont(new Font("Segoe UI", Font.BOLD, 15));
        label.setForeground(Ui.INK);
        label.setBorder(new EmptyBorder(12, 0, 9, 0));
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        parent.add(label);
    }

    private void addField(JPanel parent, String label, JComponent field) {
        JLabel l = new JLabel(label);
        l.setFont(new Font("Segoe UI", Font.BOLD, 12));
        l.setForeground(Ui.INK);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        style(field);
        field.setMaximumSize(new Dimension(720, 40));
        field.setAlignmentX(Component.LEFT_ALIGNMENT);
        parent.add(l);
        parent.add(Box.createVerticalStrut(5));
        parent.add(field);
        parent.add(Box.createVerticalStrut(12));
    }

    private void style(JComponent field) {
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Ui.BORDER),
                new EmptyBorder(7, 10, 7, 10)));
    }

    private void save() {
        char[] current = currentPassword.getPassword();
        char[] next = newPassword.getPassword();
        char[] confirmation = confirmPassword.getPassword();
        try {
            if (next.length > 0 && !Arrays.equals(next, confirmation)) throw new IllegalArgumentException("The new password entries do not match.");
            if (next.length == 0 && confirmation.length > 0) throw new IllegalArgumentException("Enter the new password in both fields.");
            Integer semesterValue = null;
            if (user.role().equals("STUDENT") && !semester.getText().isBlank()) semesterValue = Integer.parseInt(semester.getText().trim());
            ProfileDetails details = new ProfileDetails(phone.getText(), designation.getText(), department.getText(),
                    officeLocation.getText(), availability.getText(), program.getText(), semesterValue,
                    batch.getText(), section.getText());
            User updated = Main.updateProfile(user, name.getText(), details, current, next);
            JOptionPane.showMessageDialog(this, "Profile saved.", "Profile", JOptionPane.INFORMATION_MESSAGE);
            onUpdated.accept(updated);
        } catch (Exception e) {
            String message = e.getMessage() == null ? "Your profile could not be updated." : e.getMessage();
            JOptionPane.showMessageDialog(this, message, "Profile update failed", JOptionPane.WARNING_MESSAGE);
        } finally {
            Arrays.fill(current, '\0');
            Arrays.fill(next, '\0');
            Arrays.fill(confirmation, '\0');
            currentPassword.setText(""); newPassword.setText(""); confirmPassword.setText("");
        }
    }
}
