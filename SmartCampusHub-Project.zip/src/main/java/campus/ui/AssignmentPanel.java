package campus.ui;

import campus.Database;
import campus.User;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/** Searchable course-work list with student filters and a compact faculty grading desk. */
public final class AssignmentPanel extends JPanel {
    private final User user;
    private final JTable table = Ui.table();
    private final JComboBox<String> statusFilter = new JComboBox<>(new String[]{"All coursework", "Not submitted", "Awaiting feedback", "Graded", "Past deadline"});

    public AssignmentPanel(User user) {
        this.user = user;
        setLayout(new BorderLayout(0, 16)); setBackground(Ui.BG);
        setBorder(new EmptyBorder(24, 28, 22, 28));
        JPanel page = Ui.page("Assignments", "Coursework, deadlines, submissions and feedback");
        JPanel top = new JPanel(new BorderLayout(0, 14)); top.setOpaque(false);
        top.add(page.getComponent(0), BorderLayout.NORTH);
        JPanel tools = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)); tools.setOpaque(false);
        JButton refresh = Ui.secondaryButton("Refresh"); refresh.addActionListener(e -> load()); tools.add(refresh);
        if (user.role().equals("FACULTY")) {
            JButton create = Ui.button("＋  Create assignment"); create.addActionListener(e -> create()); tools.add(create);
            JButton review = Ui.secondaryButton("Review submissions"); review.addActionListener(e -> review()); tools.add(review);
        } else if (user.role().equals("STUDENT")) {
            statusFilter.setFont(new Font("Segoe UI", Font.PLAIN, 12)); statusFilter.setPreferredSize(new Dimension(170, 38));
            statusFilter.addActionListener(e -> load()); tools.add(statusFilter);
            JButton submit = Ui.button("Submit / resubmit"); submit.addActionListener(e -> submit()); tools.add(submit);
        }
        tools.add(Ui.tableTools(table, "Search coursework"));
        top.add(tools, BorderLayout.SOUTH); add(top, BorderLayout.NORTH); add(Ui.scroll(table), BorderLayout.CENTER);
        load();
    }

    private void load() {
        boolean student = user.role().equals("STUDENT");
        String sql;
        if (student) {
            sql = "SELECT a.id,c.code Course,a.title Assignment,a.description Details,DATE_FORMAT(a.due_at,'%a, %d %b · %h:%i %p') Deadline,"
                    + "IF(s.id IS NULL,'Not submitted',IF(s.marks IS NULL,'Awaiting feedback','Graded')) Status,s.marks Score,s.feedback Feedback "
                    + "FROM assignments a JOIN courses c ON c.id=a.course_id JOIN enrolments e ON e.course_id=c.id "
                    + "LEFT JOIN submissions s ON s.assignment_id=a.id AND s.student_id=" + user.id() + " WHERE e.student_id=" + user.id();
            sql += switch (statusFilter.getSelectedIndex()) {
                case 1 -> " AND s.id IS NULL";
                case 2 -> " AND s.id IS NOT NULL AND s.marks IS NULL";
                case 3 -> " AND s.marks IS NOT NULL";
                case 4 -> " AND a.due_at<NOW()";
                default -> "";
            };
            sql += " ORDER BY a.due_at";
        } else {
            sql = "SELECT a.id,c.code Course,a.title Assignment,a.description Details,DATE_FORMAT(a.due_at,'%a, %d %b · %h:%i %p') Deadline,"
                    + "(SELECT COUNT(*) FROM submissions s WHERE s.assignment_id=a.id) Submissions FROM assignments a JOIN courses c ON c.id=a.course_id"
                    + (user.role().equals("FACULTY") ? " WHERE a.created_by=" + user.id() : "") + " ORDER BY a.due_at";
        }
        Ui.load(table, sql);
        if (student) { Ui.setColumnWidths(table,0,100,250,300,190,150,80,230); Ui.wrapTextColumns(table,2,3,7); }
        else { Ui.setColumnWidths(table,0,110,270,330,200,105); Ui.wrapTextColumns(table,2,3); }
    }

    private void create() {
        List<CourseChoice> courses;
        try (Connection c=Database.connect();PreparedStatement p=c.prepareStatement("SELECT id,code,title FROM courses WHERE faculty_id=? ORDER BY code")) {
            p.setLong(1,user.id());try(ResultSet r=p.executeQuery()){courses=new ArrayList<>();while(r.next())courses.add(new CourseChoice(r.getLong(1),r.getString(2),r.getString(3)));}
        } catch(Exception e){Ui.error(this,e);return;}
        if(courses.isEmpty()){JOptionPane.showMessageDialog(this,"No courses are assigned to your account.");return;}
        JComboBox<CourseChoice> course=new JComboBox<>(courses.toArray(CourseChoice[]::new));
        JTextField title=new JTextField(28);JTextArea details=new JTextArea(5,28);details.setLineWrap(true);details.setWrapStyleWord(true);
        JTextField deadline=new JTextField(LocalDateTime.now().plusDays(14).withHour(23).withMinute(59).withSecond(0).withNano(0).toString().replace('T',' '),25);
        JPanel form=new JPanel(new GridBagLayout());form.setBackground(Color.WHITE);form.setBorder(new EmptyBorder(8,8,8,8));
        GridBagConstraints g=new GridBagConstraints();g.gridx=0;g.gridy=0;g.anchor=GridBagConstraints.WEST;g.fill=GridBagConstraints.HORIZONTAL;g.weightx=1;g.insets=new Insets(4,4,7,4);
        addField(form,g,"Course",course);addField(form,g,"Assignment title",title);addField(form,g,"Instructions and submission requirements",new JScrollPane(details));addField(form,g,"Due date  ·  YYYY-MM-DD HH:MM:SS",deadline);
        if(JOptionPane.showConfirmDialog(this,form,"Create course assignment",JOptionPane.OK_CANCEL_OPTION,JOptionPane.PLAIN_MESSAGE)!=JOptionPane.OK_OPTION)return;
        if(title.getText().isBlank()||details.getText().isBlank()){JOptionPane.showMessageDialog(this,"Add a title and clear submission instructions.");return;}
        try(Connection c=Database.connect();PreparedStatement p=c.prepareStatement("INSERT INTO assignments(course_id,created_by,title,description,due_at) VALUES(?,?,?,?,?)")){
            p.setLong(1,((CourseChoice)course.getSelectedItem()).id());p.setLong(2,user.id());p.setString(3,title.getText().trim());p.setString(4,details.getText().trim());p.setTimestamp(5,Timestamp.valueOf(deadline.getText().trim()));p.executeUpdate();load();
        }catch(Exception e){Ui.error(this,e);}
    }

    private void addField(JPanel panel,GridBagConstraints g,String label,Component control){
        JLabel heading=new JLabel(label);heading.setFont(new Font("Segoe UI",Font.BOLD,12));heading.setForeground(Ui.INK);g.gridy++;panel.add(heading,g);g.gridy++;control.setFont(new Font("Segoe UI",Font.PLAIN,13));panel.add(control,g);
    }

    private void submit(){
        int row=table.getSelectedRow();if(row<0){JOptionPane.showMessageDialog(this,"Select an assignment first.");return;}
        long id=Long.parseLong(table.getValueAt(row,0).toString());JTextArea body=new JTextArea(8,35);body.setLineWrap(true);body.setWrapStyleWord(true);
        JPanel form=new JPanel(new BorderLayout(0,8));form.add(new JLabel("Add your answer or paste the text of your work."),BorderLayout.NORTH);form.add(new JScrollPane(body),BorderLayout.CENTER);
        if(JOptionPane.showConfirmDialog(this,form,"Submit assignment",JOptionPane.OK_CANCEL_OPTION,JOptionPane.PLAIN_MESSAGE)!=JOptionPane.OK_OPTION||body.getText().isBlank())return;
        String sql="INSERT INTO submissions(assignment_id,student_id,body) SELECT ?,?,? WHERE EXISTS(SELECT 1 FROM assignments a JOIN enrolments e ON e.course_id=a.course_id WHERE a.id=? AND e.student_id=?) ON DUPLICATE KEY UPDATE body=VALUES(body),submitted_at=CURRENT_TIMESTAMP,marks=NULL,feedback=NULL";
        try(Connection c=Database.connect();PreparedStatement p=c.prepareStatement(sql)){p.setLong(1,id);p.setLong(2,user.id());p.setString(3,body.getText().trim());p.setLong(4,id);p.setLong(5,user.id());if(p.executeUpdate()==0)throw new SQLException("You are not enrolled in this assignment's course.");load();JOptionPane.showMessageDialog(this,"Your work has been submitted.","Submission saved",JOptionPane.INFORMATION_MESSAGE);}
        catch(Exception e){Ui.error(this,e);}
    }

    private void review(){
        int row=table.getSelectedRow();if(row<0){JOptionPane.showMessageDialog(this,"Select an assignment first.");return;}
        long assignmentId=Long.parseLong(table.getValueAt(row,0).toString());JTable submissions=Ui.table();
        Ui.load(submissions,"SELECT s.id,u.full_name Student,s.body Work,DATE_FORMAT(s.submitted_at,'%d %b %Y, %h:%i %p') Submitted,s.marks Marks,s.feedback Feedback FROM submissions s JOIN users u ON u.id=s.student_id JOIN assignments a ON a.id=s.assignment_id WHERE s.assignment_id=? AND a.created_by=? ORDER BY s.submitted_at DESC",assignmentId,user.id());
        Ui.setColumnWidths(submissions,0,190,340,180,80,240);Ui.wrapTextColumns(submissions,2,5);
        JPanel dialog=new JPanel(new BorderLayout(0,10));dialog.setPreferredSize(new Dimension(900,440));dialog.add(new JLabel("Select a submission, then use Grade selected."),BorderLayout.NORTH);dialog.add(Ui.scroll(submissions),BorderLayout.CENTER);
        JButton grade=Ui.button("Grade selected");grade.addActionListener(e->{gradeSubmission(submissions);load();});
        JButton close=Ui.secondaryButton("Done");JPanel buttons=new JPanel(new FlowLayout(FlowLayout.RIGHT));buttons.add(grade);buttons.add(close);dialog.add(buttons,BorderLayout.SOUTH);
        JDialog window=new JDialog(SwingUtilities.getWindowAncestor(this),"Submission review",Dialog.ModalityType.APPLICATION_MODAL);window.setContentPane(dialog);close.addActionListener(e->window.dispose());
        submissions.addMouseListener(new java.awt.event.MouseAdapter(){@Override public void mouseClicked(java.awt.event.MouseEvent e){if(e.getClickCount()==2)gradeSubmission(submissions);}});
        window.setSize(940,510);window.setLocationRelativeTo(this);window.setVisible(true);
    }

    private void gradeSubmission(JTable submissions){
        int row=submissions.getSelectedRow();if(row<0){JOptionPane.showMessageDialog(this,"Select a submission first.");return;}
        long submissionId=Long.parseLong(submissions.getValueAt(row,0).toString());JTextField score=new JTextField(8);score.setText(submissions.getValueAt(row,4)==null?"":submissions.getValueAt(row,4).toString());
        JTextArea feedback=new JTextArea(submissions.getValueAt(row,5)==null?"":submissions.getValueAt(row,5).toString(),5,28);feedback.setLineWrap(true);feedback.setWrapStyleWord(true);
        JPanel form=new JPanel(new GridLayout(0,1,5,5));form.add(new JLabel("Score out of 100"));form.add(score);form.add(new JLabel("Feedback for the student"));form.add(new JScrollPane(feedback));
        if(JOptionPane.showConfirmDialog(this,form,"Grade submission",JOptionPane.OK_CANCEL_OPTION,JOptionPane.PLAIN_MESSAGE)!=JOptionPane.OK_OPTION)return;
        try{double marks=Double.parseDouble(score.getText());if(marks<0||marks>100)throw new IllegalArgumentException("Score must be between 0 and 100.");
            try(Connection c=Database.connect();PreparedStatement p=c.prepareStatement("UPDATE submissions s JOIN assignments a ON a.id=s.assignment_id SET s.marks=?,s.feedback=? WHERE s.id=? AND a.created_by=?")){p.setDouble(1,marks);p.setString(2,feedback.getText().trim());p.setLong(3,submissionId);p.setLong(4,user.id());if(p.executeUpdate()!=1)throw new SQLException("This submission is no longer available to grade.");}
        }catch(Exception e){Ui.error(this,e);}
    }

    private record CourseChoice(long id,String code,String title){@Override public String toString(){return code+"  ·  "+title;}}
}
