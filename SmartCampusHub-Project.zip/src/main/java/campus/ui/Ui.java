package campus.ui;

import javax.swing.*;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.MouseEvent;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.TableRowSorter;
import java.io.BufferedWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.regex.Pattern;

/** Shared visual system and small JDBC table helpers for the Swing screens. */
public final class Ui {
    private Ui() {}

    public static final Color NAVY = new Color(17, 31, 58);
    public static final Color BLUE = new Color(55, 111, 226);
    public static final Color GOLD = new Color(255, 190, 92);
    public static final Color BG = new Color(244, 247, 251);
    public static final Color INK = new Color(27, 39, 62);
    public static final Color MUTED = new Color(111, 124, 146);
    public static final Color BORDER = new Color(226, 233, 242);
    public static final Color TEAL = new Color(35, 173, 155);
    public static final Color SURFACE = Color.WHITE;

    public static JPanel page(String title, String subtitle) {
        JPanel p = new JPanel(new BorderLayout(0, 20));
        p.setBackground(BG);
        p.setBorder(BorderFactory.createEmptyBorder(28, 30, 25, 30));
        JPanel head = new JPanel();
        head.setOpaque(false);
        head.setLayout(new BoxLayout(head, BoxLayout.Y_AXIS));
        JLabel t = new JLabel(title);
        t.setFont(new Font("Segoe UI", Font.BOLD, 25));
        t.setForeground(INK);
        JLabel s = new JLabel(subtitle);
        s.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        s.setForeground(MUTED);
        head.add(t);
        head.add(Box.createVerticalStrut(5));
        head.add(s);
        p.add(head, BorderLayout.NORTH);
        return p;
    }

    public static JPanel card() {
        JPanel p = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics graphics) {
                Graphics2D g = (Graphics2D) graphics.create();
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g.setColor(new Color(28, 39, 72, 9));
                g.fillRoundRect(1, 3, getWidth() - 3, getHeight() - 3, 20, 20);
                g.setColor(Color.WHITE);
                g.fillRoundRect(0, 0, getWidth() - 3, getHeight() - 5, 20, 20);
                g.setColor(BORDER);
                g.drawRoundRect(0, 0, getWidth() - 3, getHeight() - 6, 20, 20);
                g.dispose();
                super.paintComponent(graphics);
            }
        };
        p.setOpaque(false);
        p.setBorder(BorderFactory.createEmptyBorder(16, 18, 16, 18));
        return p;
    }

    public static JTable table() {
        JTable t = new JTable() {
            @Override public String getToolTipText(MouseEvent event) {
                int row = rowAtPoint(event.getPoint());
                int column = columnAtPoint(event.getPoint());
                if (row < 0 || column < 0) return null;
                Object value = getValueAt(row, column);
                return value == null ? null : value.toString();
            }
        };
        t.setToolTipText(" ");
        t.setRowHeight(43);
        t.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        t.setForeground(INK);
        t.setSelectionBackground(new Color(234, 232, 255));
        t.setSelectionForeground(INK);
        t.setGridColor(new Color(240, 241, 246));
        t.setShowVerticalLines(false);
        t.setFillsViewportHeight(true);
        t.setIntercellSpacing(new Dimension(0, 1));
        t.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        t.getTableHeader().setForeground(INK);
        t.getTableHeader().setBackground(new Color(249, 249, 252));
        t.getTableHeader().setPreferredSize(new Dimension(0, 42));
        t.setShowHorizontalLines(true);
        t.setAutoCreateRowSorter(true);
        return t;
    }

    public static JScrollPane scroll(JTable table) {
        JScrollPane pane = new JScrollPane(table);
        pane.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDER),
                BorderFactory.createEmptyBorder(1, 1, 1, 1)));
        pane.getViewport().setBackground(Color.WHITE);
        return pane;
    }

    /** Adds a case-insensitive live search across all visible table columns. */
    public static void installSearch(JTable table, JTextField field) {
        Runnable apply = () -> {
            TableRowSorter<javax.swing.table.TableModel> sorter = new TableRowSorter<>(table.getModel());
            table.setRowSorter(sorter);
            String value = field.getText().trim();
            sorter.setRowFilter(value.isEmpty() ? null : RowFilter.regexFilter("(?i)" + Pattern.quote(value)));
        };
        field.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { apply.run(); }
            public void removeUpdate(DocumentEvent e) { apply.run(); }
            public void changedUpdate(DocumentEvent e) { apply.run(); }
        });
        table.addPropertyChangeListener("model", e -> SwingUtilities.invokeLater(apply));
        apply.run();
    }

    public static int modelRow(JTable table, int viewRow) {
        return viewRow < 0 ? -1 : table.convertRowIndexToModel(viewRow);
    }

    public static String navGlyph(String label) {
        return switch (label) {
            case "Dashboard" -> "⌂";
            case "Attendance" -> "◷";
            case "Assignments" -> "▤";
            case "Quizzes & Results" -> "◈";
            case "Events & Notices" -> "✦";
            case "Administration" -> "⚙";
            case "My Profile" -> "◎";
            default -> "•";
        };
    }

    public static String metricGlyph(String label) {
        String value = label.toLowerCase(java.util.Locale.ROOT);
        if (value.contains("attendance")) return "◷";
        if (value.contains("assignment")) return "▤";
        if (value.contains("quiz")) return "✎";
        if (value.contains("event")) return "✦";
        if (value.contains("notice")) return "◉";
        if (value.contains("review")) return "✓";
        if (value.contains("student")) return "♙";
        if (value.contains("faculty") || value.contains("course")) return "⌂";
        return "◈";
    }

    /** Modern toolbar shared by data modules: live search plus one-click CSV export. */
    public static JPanel tableTools(JTable table, String hint) {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        bar.setOpaque(false);
        JTextField search = searchField(hint, 20);
        installSearch(table, search);
        JButton export = secondaryButton("Export CSV");
        export.addActionListener(e -> exportCsv(table));
        bar.add(search);
        bar.add(export);
        return bar;
    }

    public static void exportCsv(JTable table) {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Export visible records");
        chooser.setSelectedFile(new java.io.File("campus-records.csv"));
        if (chooser.showSaveDialog(table) != JFileChooser.APPROVE_OPTION) return;
        Path path = chooser.getSelectedFile().toPath();
        if (!path.getFileName().toString().toLowerCase(java.util.Locale.ROOT).endsWith(".csv"))
            path = path.resolveSibling(path.getFileName() + ".csv");
        try (BufferedWriter out = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
            out.write(0xFEFF);
            for (int c = 0; c < table.getColumnCount(); c++) {
                if (c > 0) out.write(',');
                out.write(csv(table.getColumnName(c)));
            }
            out.newLine();
            for (int row = 0; row < table.getRowCount(); row++) {
                for (int c = 0; c < table.getColumnCount(); c++) {
                    if (c > 0) out.write(',');
                    out.write(csv(String.valueOf(table.getValueAt(row, c) == null ? "" : table.getValueAt(row, c))));
                }
                out.newLine();
            }
            JOptionPane.showMessageDialog(table, "Exported " + table.getRowCount() + " visible rows to " + path.getFileName(),
                    "Export complete", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) { error(table, ex); }
    }

    private static String csv(String value) { return "\"" + value.replace("\"", "\"\"") + "\""; }

    /** Wraps a page in a short, low-motion fade/slide reveal. */
    public static JPanel reveal(Component page) {
        JPanel wrapper = new JPanel(new BorderLayout()) {
            private float progress;
            private final Timer timer = new Timer(16, null);
            {
                timer.addActionListener(e -> {
                    progress = Math.min(1f, progress + .12f);
                    repaint();
                    if (progress >= 1f) timer.stop();
                });
                timer.start();
            }
            @Override protected void paintChildren(Graphics graphics) {
                Graphics2D g = (Graphics2D) graphics.create();
                g.setComposite(AlphaComposite.SrcOver.derive(progress));
                g.translate(0, Math.round((1f - progress) * 8f));
                super.paintChildren(g);
                g.dispose();
            }
        };
        wrapper.setOpaque(false);
        wrapper.add(page, BorderLayout.CENTER);
        return wrapper;
    }

    public static JTextField searchField(String placeholder, int columns) {
        JTextField field = new JTextField(columns) {
            @Override protected void paintComponent(Graphics graphics) {
                super.paintComponent(graphics);
                if (getText().isEmpty() && !isFocusOwner()) {
                    Graphics2D g=(Graphics2D)graphics.create();g.setColor(MUTED);g.setFont(getFont());
                    Insets in=getInsets();g.drawString(placeholder,in.left+1,getHeight()/2+g.getFontMetrics().getAscent()/2-1);g.dispose();
                }
            }
        };
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setForeground(INK);
        field.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDER),
                BorderFactory.createEmptyBorder(8, 11, 8, 11)));
        field.setPreferredSize(new Dimension(230, 38));
        field.setToolTipText(placeholder);
        return field;
    }

    /** Vector-drawn campus illustration, so the packaged app needs no external image downloads. */
    public static final class CampusArtwork extends JPanel {
        private float phase;
        private final Timer animation;
        public CampusArtwork() {
            setOpaque(false);
            setPreferredSize(new Dimension(290, 180));
            animation = new Timer(45, e -> { phase += .025f; repaint(); });
        }
        @Override public void addNotify() { super.addNotify(); animation.start(); }
        @Override public void removeNotify() { animation.stop(); super.removeNotify(); }
        @Override protected void paintComponent(Graphics graphics) {
            super.paintComponent(graphics);
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight();
            g.setColor(new Color(255, 255, 255, 24));
            g.fillOval(w - 125, -35, 150, 150);
            g.fillOval(w - 200, 20, 76, 76);
            int lift = (int) (Math.sin(phase) * 3);
            g.setColor(new Color(255, 255, 255, 42));
            g.fillRoundRect(28, h - 45, w - 54, 22, 18, 18);
            g.setColor(new Color(255, 255, 255, 220));
            g.fillRoundRect(67, 54 + lift, 146, 93, 13, 13);
            g.setColor(new Color(246, 247, 255));
            int[] roofX = {56, 140, 224}, roofY = {60 + lift, 18 + lift, 60 + lift};
            g.fillPolygon(roofX, roofY, 3);
            g.setColor(new Color(92, 82, 225));
            g.fillRoundRect(78, 68 + lift, 124, 11, 5, 5);
            g.fillRoundRect(124, 105 + lift, 32, 42, 5, 5);
            g.setColor(new Color(66, 190, 183));
            for (int x : new int[]{84, 106, 174, 194}) {
                g.fillRoundRect(x, 91 + lift, 12, 18, 3, 3);
                g.setColor(new Color(231, 247, 247));
                g.fillRoundRect(x + 3, 94 + lift, 2, 12, 2, 2);
                g.setColor(new Color(66, 190, 183));
            }
            g.setColor(new Color(255, 190, 92));
            g.fillOval(139, 33 + lift, 7, 7);
            g.setColor(new Color(255, 255, 255, 90));
            g.setStroke(new BasicStroke(1.5f));
            g.drawArc(20, 26, 54, 38, 190, 150);
            g.drawArc(w - 73, 82, 44, 40, -20, 160);
            g.dispose();
        }
        public void stop() { animation.stop(); }
    }

    /** Applies predictable widths after a table model is loaded; width 0 hides an internal key column. */
    public static void setColumnWidths(JTable table, int... widths) {
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        int count = Math.min(table.getColumnModel().getColumnCount(), widths.length);
        for (int i = 0; i < count; i++) {
            var column = table.getColumnModel().getColumn(i);
            if (widths[i] == 0) {
                column.setMinWidth(0);
                column.setMaxWidth(0);
                column.setPreferredWidth(0);
                column.setWidth(0);
            } else {
                column.setMinWidth(Math.min(55, widths[i]));
                column.setPreferredWidth(widths[i]);
                column.setWidth(widths[i]);
            }
        }
    }

    /** Wraps selected text-heavy columns and grows each row to show its full cell content. */
    public static void wrapTextColumns(JTable table, int... indexes) {
        java.util.List<Integer> visible = new java.util.ArrayList<>();
        for (int index : indexes) {
            if (index >= 0 && index < table.getColumnModel().getColumnCount()) {
                table.getColumnModel().getColumn(index).setCellRenderer(new WrappedCellRenderer());
                visible.add(index);
            }
        }
        for (int row = 0; row < table.getRowCount(); row++) {
            int height = table.getRowHeight();
            for (int column : visible) {
                TableCellRenderer renderer = table.getColumnModel().getColumn(column).getCellRenderer();
                if (renderer instanceof WrappedCellRenderer wrapped) height = Math.max(height, wrapped.preferredHeight(table, row, column));
            }
            table.setRowHeight(row, height);
        }
    }

    private static final class WrappedCellRenderer extends JTextArea implements TableCellRenderer {
        private WrappedCellRenderer() {
            setLineWrap(true);
            setWrapStyleWord(true);
            setOpaque(true);
            setBorder(BorderFactory.createEmptyBorder(6, 8, 6, 8));
        }

        private int preferredHeight(JTable table, int row, int column) {
            Object value = table.getValueAt(row, column);
            setFont(table.getFont());
            setText(value == null ? "" : value.toString());
            setSize(new Dimension(table.getColumnModel().getColumn(column).getWidth(), Short.MAX_VALUE));
            return Math.max(table.getRowHeight(), getPreferredSize().height);
        }

        @Override public Component getTableCellRendererComponent(JTable table, Object value, boolean selected,
                                                                   boolean focused, int row, int column) {
            setFont(table.getFont());
            setText(value == null ? "" : value.toString());
            setBackground(selected ? table.getSelectionBackground() : table.getBackground());
            setForeground(selected ? table.getSelectionForeground() : table.getForeground());
            return this;
        }
    }

    public static void load(JTable t, String sql, Object... args) {
        try (var c = campus.Database.connect(); var p = c.prepareStatement(sql)) {
            for (int i = 0; i < args.length; i++) p.setObject(i + 1, args[i]);
            try (var r = p.executeQuery()) {
                var m = new DefaultTableModel();
                var md = r.getMetaData();
                for (int i = 1; i <= md.getColumnCount(); i++) m.addColumn(md.getColumnLabel(i));
                while (r.next()) {
                    Object[] row = new Object[md.getColumnCount()];
                    for (int i = 0; i < row.length; i++) row[i] = r.getObject(i + 1);
                    m.addRow(row);
                }
                t.setModel(m);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(t, "Could not load records: " + e.getMessage(), "Database error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void error(Component c, Exception e) {
        JOptionPane.showMessageDialog(c, e.getMessage(), "Operation failed", JOptionPane.ERROR_MESSAGE);
    }

    public static JButton button(String s) {
        JButton b = new JButton(s) {
            @Override protected void paintComponent(Graphics graphics) {
                Graphics2D g = (Graphics2D) graphics.create();
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                ButtonModel model = getModel();
                Color fill = model.isPressed() ? new Color(27, 73, 145)
                        : model.isRollover() ? new Color(54, 116, 207) : BLUE;
                g.setColor(fill);
                g.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                if (hasFocus()) {
                    g.setColor(GOLD);
                    g.setStroke(new BasicStroke(1.5f));
                    g.drawRoundRect(2, 2, getWidth() - 5, getHeight() - 5, 10, 10);
                }
                g.dispose();
                super.paintComponent(graphics);
            }
        };
        b.setUI(new BasicButtonUI());
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setForeground(Color.WHITE);
        b.setContentAreaFilled(false);
        b.setOpaque(false);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setBorder(BorderFactory.createEmptyBorder(10, 16, 10, 16));
        b.setRolloverEnabled(true);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    public static JButton secondaryButton(String s) {
        JButton b = new JButton(s) {
            @Override protected void paintComponent(Graphics graphics) {
                Graphics2D g = (Graphics2D) graphics.create();
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                ButtonModel model = getModel();
                g.setColor(model.isPressed() ? new Color(236, 242, 250)
                        : model.isRollover() ? new Color(245, 248, 252) : Color.WHITE);
                g.fillRoundRect(0, 0, getWidth(), getHeight(), 11, 11);
                g.setColor(hasFocus() ? BLUE : BORDER);
                g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 11, 11);
                g.dispose();
                super.paintComponent(graphics);
            }
        };
        b.setUI(new BasicButtonUI());
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setForeground(INK);
        b.setContentAreaFilled(false);
        b.setOpaque(false);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setBorder(BorderFactory.createEmptyBorder(9, 14, 9, 14));
        b.setRolloverEnabled(true);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }
}
