package campus.ui;

import campus.Database;
import campus.Security;
import campus.User;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.sql.*;

/** Administrator-only account, course, and enrolment management. */
public final class AdminPanel extends JPanel {
    private final User admin;
    private final JTable users = Ui.table();
    private final JTable courses = Ui.table();
    private final JTable enrolled = Ui.table();
    private final JTextField userSearch = new JTextField(18);
    private final JTextField courseSearch = Ui.searchField("Filter courses", 16);
    private final JComboBox<String> roleFilter = new JComboBox<>(new String[]{"ALL", "ADMIN", "FACULTY", "STUDENT"});

    public AdminPanel(User user) {
        if (!"ADMIN".equals(user.role())) throw new SecurityException("Administrator access required.");
        admin = user;
        setLayout(new BorderLayout());
        setBackground(Ui.BG);
        setBorder(BorderFactory.createEmptyBorder(24, 28, 24, 28));
        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Segoe UI", Font.BOLD, 13));
        tabs.addTab("User accounts", userTab());
        tabs.addTab("Courses and enrolments", courseTab());
        add(tabs, BorderLayout.CENTER);
        loadUsers();
        loadCourses();
        if (courses.getRowCount() > 0) courses.setRowSelectionInterval(0, 0);
    }

    private JPanel userTab() {
        JPanel p = modulePanel("User accounts", "Create campus accounts, search users and control account access");
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        actions.setOpaque(false);
        userSearch.putClientProperty("JTextField.placeholderText", "Search name or email");
        JButton search = Ui.secondaryButton("Search");
        JButton add = Ui.button("Create account");
        JButton toggle = Ui.secondaryButton("Activate / deactivate");
        JButton reset = Ui.secondaryButton("Set temporary password");
        JButton export = Ui.secondaryButton("Export CSV"); export.addActionListener(e -> Ui.exportCsv(users));
        actions.add(userSearch); actions.add(roleFilter); actions.add(search); actions.add(add); actions.add(toggle); actions.add(reset); actions.add(export);
        search.addActionListener(e -> loadUsers());
        userSearch.addActionListener(e -> loadUsers());
        roleFilter.addActionListener(e -> loadUsers());
        add.addActionListener(e -> createUser());
        toggle.addActionListener(e -> toggleUser());
        reset.addActionListener(e -> resetPassword());
        JPanel top = new JPanel(new BorderLayout(0, 14));
        top.setOpaque(false);
        top.add(p.getComponent(0), BorderLayout.NORTH);
        top.add(actions, BorderLayout.SOUTH);
        JPanel result = new JPanel(new BorderLayout(0, 12));
        result.setBackground(Ui.BG);
        result.add(top, BorderLayout.NORTH);
        result.add(Ui.scroll(users), BorderLayout.CENTER);
        return result;
    }

    private JPanel courseTab() {
        JPanel p = modulePanel("Courses and enrolments", "Assign faculty to courses and maintain student enrolments");
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        actions.setOpaque(false);
        JButton create = Ui.button("Create course");
        JButton faculty = Ui.secondaryButton("Assign faculty");
        JButton enrol = Ui.secondaryButton("Enrol student by email");
        JButton remove = Ui.secondaryButton("Remove selected enrolment");
        JButton refresh = Ui.secondaryButton("Refresh");
        JButton exportCourses = Ui.secondaryButton("Export courses"); exportCourses.addActionListener(e -> Ui.exportCsv(courses));
        actions.add(create); actions.add(faculty); actions.add(enrol); actions.add(remove); actions.add(refresh); actions.add(exportCourses); actions.add(courseSearch);
        create.addActionListener(e -> createCourse());
        faculty.addActionListener(e -> assignFaculty());
        enrol.addActionListener(e -> enrolStudent());
        remove.addActionListener(e -> removeEnrolment());
        refresh.addActionListener(e -> { loadCourses(); loadEnrolled(); });
        courses.getSelectionModel().addListSelectionListener(e -> { if (!e.getValueIsAdjusting()) loadEnrolled(); });
        JPanel top = new JPanel(new BorderLayout(0, 14));
        top.setOpaque(false);
        top.add(p.getComponent(0), BorderLayout.NORTH);
        top.add(actions, BorderLayout.SOUTH);
        JPanel lower = new JPanel(new BorderLayout(0, 7));
        lower.setBackground(Ui.BG);
        JLabel enrolledLabel = new JLabel("Students enrolled in selected course");
        enrolledLabel.setForeground(Ui.INK);
        enrolledLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lower.add(enrolledLabel, BorderLayout.NORTH);
        lower.add(Ui.scroll(enrolled), BorderLayout.CENTER);
        JButton exportEnrolments = Ui.secondaryButton("Export enrolments"); exportEnrolments.addActionListener(e -> Ui.exportCsv(enrolled));
        lower.add(exportEnrolments, BorderLayout.SOUTH);
        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT, Ui.scroll(courses), lower);
        split.setResizeWeight(0.56);
        split.setBorder(null);
        JPanel result = new JPanel(new BorderLayout(0, 12));
        result.setBackground(Ui.BG);
        result.add(top, BorderLayout.NORTH);
        result.add(split, BorderLayout.CENTER);
        return result;
    }

    private JPanel modulePanel(String title, String subtitle) {
        JPanel p = Ui.page(title, subtitle);
        p.setOpaque(false);
        return p;
    }

    private void loadUsers() {
        String needle = "%" + userSearch.getText().trim() + "%";
        String selectedRole = roleFilter.getSelectedItem().toString();
        String sql = "SELECT id AS ID,full_name AS Name,email AS Email,role AS Role,IF(active,'Active','Inactive') AS Status,DATE_FORMAT(created_at,'%d %b %Y, %h:%i %p') AS Created "
                + "FROM users WHERE (full_name LIKE ? OR email LIKE ?)" + (selectedRole.equals("ALL") ? "" : " AND role=?") + " ORDER BY role,full_name";
        if (selectedRole.equals("ALL")) Ui.load(users, sql, needle, needle);
        else Ui.load(users, sql, needle, needle, selectedRole);
        hideId(users, 0);
        Ui.setColumnWidths(users, 0, 170, 245, 105, 110, 220);
        Ui.installSearch(users, userSearch);
    }

    private void loadCourses() {
        Ui.load(courses, "SELECT c.id AS ID,c.code AS Code,c.title AS Course,f.full_name AS Faculty,f.email AS `Faculty Email` "
                + "FROM courses c JOIN users f ON f.id=c.faculty_id ORDER BY c.code");
        hideId(courses, 0);
        Ui.setColumnWidths(courses, 0, 120, 300, 210, 300);
        Ui.wrapTextColumns(courses, 2);
        Ui.installSearch(courses, courseSearch);
    }

    private void loadEnrolled() {
        int row = courses.getSelectedRow();
        if (row < 0) { enrolled.setModel(new javax.swing.table.DefaultTableModel()); return; }
        long courseId = selectedId(courses, 0);
        Ui.load(enrolled, "SELECT u.id AS ID,u.full_name AS Student,u.email AS Email,IF(u.active,'Active','Inactive') AS Status "
                + "FROM enrolments e JOIN users u ON u.id=e.student_id WHERE e.course_id=? ORDER BY u.full_name", courseId);
        hideId(enrolled, 0);
        Ui.setColumnWidths(enrolled, 0, 220, 400, 130);
    }

    private void createUser() {
        JTextField name = new JTextField();
        JTextField email = new JTextField();
        JComboBox<String> role = new JComboBox<>(new String[]{"STUDENT", "FACULTY"});
        JPasswordField password = new JPasswordField();
        boolean[] manualEmail = {false};
        boolean[] fillingEmail = {false};
        Runnable suggestEmail = () -> {
            if (!manualEmail[0] && "STUDENT".equals(role.getSelectedItem())) {
                fillingEmail[0] = true;
                email.setText(campus.Main.suggestedStudentEmail(name.getText()));
                fillingEmail[0] = false;
            }
        };
        name.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { suggestEmail.run(); }
            public void removeUpdate(DocumentEvent e) { suggestEmail.run(); }
            public void changedUpdate(DocumentEvent e) { suggestEmail.run(); }
        });
        email.getDocument().addDocumentListener(new DocumentListener() {
            private void check() { if (!fillingEmail[0] && !email.getText().equals(campus.Main.suggestedStudentEmail(name.getText()))) manualEmail[0] = true; }
            public void insertUpdate(DocumentEvent e) { check(); }
            public void removeUpdate(DocumentEvent e) { check(); }
            public void changedUpdate(DocumentEvent e) { check(); }
        });
        role.addActionListener(e -> suggestEmail.run());
        JPanel form = form("Full name", name, "Email  ·  suggested from name for students", email,
                "Role", role, "Temporary password (12+ characters)", password);
        if (JOptionPane.showConfirmDialog(this, form, "Create campus account", JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) return;
        char[] value = password.getPassword();
        try {
            validateAccount(name.getText(), email.getText(), value);
            try (Connection c = Database.connect(); PreparedStatement p = c.prepareStatement(
                    "INSERT INTO users(full_name,email,password_hash,role) VALUES(?,?,?,?)")) {
                p.setString(1, name.getText().trim());
                p.setString(2, email.getText().trim().toLowerCase());
                p.setString(3, Security.hash(value));
                p.setString(4, role.getSelectedItem().toString());
                p.executeUpdate();
            }
            JOptionPane.showMessageDialog(this, "Account created. Share the temporary password securely and ask the user to change it.");
            loadUsers();
        } catch (SQLException e) { showSqlError(e); }
        catch (IllegalArgumentException e) { JOptionPane.showMessageDialog(this, e.getMessage(), "Check account details", JOptionPane.WARNING_MESSAGE); }
        finally { java.util.Arrays.fill(value, '\0'); }
    }

    private void toggleUser() {
        if (users.getSelectedRow() < 0) { warnSelect("user"); return; }
        long id = selectedId(users, 0);
        String status = users.getValueAt(users.getSelectedRow(), 4).toString();
        if (id == admin.id()) { JOptionPane.showMessageDialog(this, "You cannot deactivate your own signed-in administrator account."); return; }
        String next = status.equals("Active") ? "deactivate" : "activate";
        if (JOptionPane.showConfirmDialog(this, "Are you sure you want to " + next + " this account?", "Confirm account change", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        try (Connection c = Database.connect(); PreparedStatement p = c.prepareStatement("UPDATE users SET active=? WHERE id=?")) {
            p.setBoolean(1, status.equals("Inactive")); p.setLong(2, id); p.executeUpdate(); loadUsers();
        } catch (SQLException e) { Ui.error(this, e); }
    }

    private void resetPassword() {
        if (users.getSelectedRow() < 0) { warnSelect("user"); return; }
        JPasswordField field = new JPasswordField(20);
        if (JOptionPane.showConfirmDialog(this, field, "Set new temporary password (12+ characters)", JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) return;
        char[] value = field.getPassword();
        try {
            if (value.length < 12) throw new IllegalArgumentException("Use at least 12 characters.");
            try (Connection c = Database.connect(); PreparedStatement p = c.prepareStatement("UPDATE users SET password_hash=? WHERE id=?")) {
                p.setString(1, Security.hash(value)); p.setLong(2, selectedId(users, 0)); p.executeUpdate();
            }
            JOptionPane.showMessageDialog(this, "Password changed. Share it securely with the verified account holder.");
        } catch (SQLException e) { Ui.error(this, e); }
        catch (IllegalArgumentException e) { JOptionPane.showMessageDialog(this, e.getMessage(), "Password", JOptionPane.WARNING_MESSAGE); }
        finally { java.util.Arrays.fill(value, '\0'); }
    }

    private void createCourse() {
        JTextField code = new JTextField();
        JTextField title = new JTextField();
        JComboBox<Person> faculty = facultyChoices();
        if (faculty.getItemCount() == 0) { JOptionPane.showMessageDialog(this, "Create or activate a faculty account first."); return; }
        JPanel form = form("Course code", code, "Course title", title, "Faculty", faculty);
        if (JOptionPane.showConfirmDialog(this, form, "Create course", JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) return;
        try (Connection c = Database.connect(); PreparedStatement p = c.prepareStatement("INSERT INTO courses(code,title,faculty_id) VALUES(?,?,?)")) {
            if (code.getText().isBlank() || title.getText().isBlank()) throw new IllegalArgumentException("Enter a course code and title.");
            p.setString(1, code.getText().trim().toUpperCase()); p.setString(2, title.getText().trim()); p.setLong(3, ((Person) faculty.getSelectedItem()).id()); p.executeUpdate();
            loadCourses();
        } catch (SQLException e) { showSqlError(e); }
        catch (IllegalArgumentException e) { JOptionPane.showMessageDialog(this, e.getMessage(), "Course", JOptionPane.WARNING_MESSAGE); }
    }

    private void assignFaculty() {
        if (courses.getSelectedRow() < 0) { warnSelect("course"); return; }
        JComboBox<Person> faculty = facultyChoices();
        if (faculty.getItemCount() == 0) { JOptionPane.showMessageDialog(this, "No active faculty accounts are available."); return; }
        if (JOptionPane.showConfirmDialog(this, faculty, "Assign course faculty", JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) return;
        try (Connection c = Database.connect(); PreparedStatement p = c.prepareStatement("UPDATE courses SET faculty_id=? WHERE id=?")) {
            p.setLong(1, ((Person) faculty.getSelectedItem()).id()); p.setLong(2, selectedId(courses, 0)); p.executeUpdate(); loadCourses();
        } catch (SQLException e) { Ui.error(this, e); }
    }

    private void enrolStudent() {
        if (courses.getSelectedRow() < 0) { warnSelect("course"); return; }
        String email = JOptionPane.showInputDialog(this, "Enter the email of an existing student account:");
        if (email == null || email.isBlank()) return;
        try (Connection c = Database.connect(); PreparedStatement p = c.prepareStatement(
                "INSERT INTO enrolments(course_id,student_id) SELECT ?,id FROM users WHERE LOWER(email)=LOWER(?) AND role='STUDENT' AND active=TRUE")) {
            p.setLong(1, selectedId(courses, 0)); p.setString(2, email.trim());
            if (p.executeUpdate() == 0) throw new SQLException("No active student account was found for that email.");
            loadEnrolled();
        } catch (SQLException e) { showSqlError(e); }
    }

    private void removeEnrolment() {
        if (courses.getSelectedRow() < 0 || enrolled.getSelectedRow() < 0) { warnSelect("course and student"); return; }
        if (JOptionPane.showConfirmDialog(this, "Remove this student's enrolment from the selected course? Existing academic history is retained.",
                "Confirm enrolment change", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        try (Connection c = Database.connect(); PreparedStatement p = c.prepareStatement("DELETE FROM enrolments WHERE course_id=? AND student_id=?")) {
            p.setLong(1, selectedId(courses, 0)); p.setLong(2, selectedId(enrolled, 0)); p.executeUpdate(); loadEnrolled();
        } catch (SQLException e) { Ui.error(this, e); }
    }

    private JComboBox<Person> facultyChoices() {
        JComboBox<Person> combo = new JComboBox<>();
        try (Connection c = Database.connect(); PreparedStatement p = c.prepareStatement("SELECT id,full_name,email FROM users WHERE role='FACULTY' AND active=TRUE ORDER BY full_name"); ResultSet r = p.executeQuery()) {
            while (r.next()) combo.addItem(new Person(r.getLong(1), r.getString(2), r.getString(3)));
        } catch (SQLException e) { Ui.error(this, e); }
        return combo;
    }

    private void validateAccount(String name, String email, char[] password) {
        if (name == null || name.trim().isBlank() || name.trim().length() > 120) throw new IllegalArgumentException("Enter a name up to 120 characters.");
        if (email == null || !email.trim().matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")) throw new IllegalArgumentException("Enter a valid email address.");
        if (password == null || password.length < 12) throw new IllegalArgumentException("Use a password with at least 12 characters.");
    }

    private JPanel form(Object... pairs) {
        JPanel panel = new JPanel(new GridLayout(0, 1, 4, 4));
        for (int i = 0; i < pairs.length; i += 2) { panel.add(new JLabel(pairs[i].toString())); panel.add((Component) pairs[i + 1]); }
        return panel;
    }

    private long selectedId(JTable table, int column) { return Long.parseLong(table.getValueAt(table.getSelectedRow(), column).toString()); }
    private void hideId(JTable table, int column) { if (table.getColumnModel().getColumnCount() > column) { var c=table.getColumnModel().getColumn(column); c.setMinWidth(0); c.setMaxWidth(0); c.setPreferredWidth(0); } }
    private void warnSelect(String what) { JOptionPane.showMessageDialog(this, "Select a " + what + " first.", "Selection required", JOptionPane.INFORMATION_MESSAGE); }
    private void showSqlError(SQLException e) { String message = e.getErrorCode() == 1062 ? "That value is already in use." : e.getMessage(); JOptionPane.showMessageDialog(this, message, "Database operation failed", JOptionPane.ERROR_MESSAGE); }
    private record Person(long id, String name, String email) { @Override public String toString() { return name + "  ·  " + email; } }
}

