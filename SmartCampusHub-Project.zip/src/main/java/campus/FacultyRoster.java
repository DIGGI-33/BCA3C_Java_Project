package campus;

import java.sql.*;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;

/** The official faculty and subject roster for the local Smart Campus Hub demo. */
public final class FacultyRoster {
    private record Faculty(String name, String email, String password, String code, String title) {}

    // Tirth uses 001 as specifically requested; the remaining demo passwords have unique suffixes.
    private static final Faculty[] PEOPLE = {
            new Faculty("Tirth Bhadeshiya", "tirthbhadeshiya@gmail.com", "tirthbhadeshiya001", "05BC3306", "Programming in Java"),
            new Faculty("Sahil Sheth", "sahilsheth@gmail.com", "sahilsheth002", "05CR0301", "Life Skill 1 (Universal Human Values)"),
            new Faculty("Sanket Jethava", "sanketjethava@gmail.com", "sanketjethava003", "05BC3301", "Database Management System-2"),
            new Faculty("Jitesh Solanki", "jiteshsolanki@gmail.com", "jiteshsolanki004", "05BC3302", "Data Structure Using C"),
            new Faculty("Shailja Palsra", "shailjapalsra@gmail.com", "shailjapalsra005", "05BC3304", "Management Information System (MIS)")
    };

    private static final String[] EMAILS = Arrays.stream(PEOPLE).map(Faculty::email).toArray(String[]::new);
    private FacultyRoster() {}

    /** Applies the roster in the caller's transaction, preserving course IDs and their student records. */
    public static void apply(Connection c) throws SQLException {
        Map<String, Long> ids = new LinkedHashMap<>();
        for (Faculty f : PEOPLE) {
            char[] password = f.password().toCharArray();
            String hash;
            try { hash = Security.hash(password); }
            finally { Arrays.fill(password, '\0'); }
            try (PreparedStatement p = c.prepareStatement(
                    "INSERT INTO users(full_name,email,password_hash,role,active) VALUES(?,?,?,'FACULTY',TRUE) "
                            + "ON DUPLICATE KEY UPDATE full_name=VALUES(full_name),password_hash=VALUES(password_hash),role='FACULTY',active=TRUE")) {
                p.setString(1, f.name()); p.setString(2, f.email()); p.setString(3, hash); p.executeUpdate();
            }
            try (PreparedStatement p = c.prepareStatement("SELECT id FROM users WHERE email=? AND role='FACULTY'")) {
                p.setString(1, f.email());
                try (ResultSet r = p.executeQuery()) {
                    if (!r.next()) throw new SQLException("Could not prepare faculty account " + f.email());
                    ids.put(f.email(), r.getLong(1));
                }
            }
        }

        // Rename the two original sample courses in place so attendance, assignments and enrolments keep their IDs.
        renameLegacyCourse(c, "BCA-JAVA", PEOPLE[0], ids.get(PEOPLE[0].email()));
        renameLegacyCourse(c, "BCA-DBMS", PEOPLE[2], ids.get(PEOPLE[2].email()));
        for (Faculty f : PEOPLE) {
            try (PreparedStatement p = c.prepareStatement("INSERT INTO courses(code,title,faculty_id) VALUES(?,?,?) "
                    + "ON DUPLICATE KEY UPDATE title=VALUES(title),faculty_id=VALUES(faculty_id)")) {
                p.setString(1, f.code()); p.setString(2, f.title()); p.setLong(3, ids.get(f.email())); p.executeUpdate();
            }
        }

        long tirth = ids.get(PEOPLE[0].email());
        String placeholders = String.join(",", java.util.Collections.nCopies(EMAILS.length, "?"));
        // Any extra demo faculty ownership is moved onto the matching course owner before the old account is deleted.
        try (PreparedStatement p = c.prepareStatement("UPDATE courses SET faculty_id=? WHERE faculty_id IN "
                + "(SELECT id FROM users WHERE role='FACULTY' AND email NOT IN (" + placeholders + "))")) {
            p.setLong(1, tirth); bindEmails(p, 2); p.executeUpdate();
        }
        for (String table : new String[]{"attendance_sessions", "assignments", "quizzes"}) {
            try (Statement s = c.createStatement()) {
                s.executeUpdate("UPDATE " + table + " x JOIN courses c ON c.id=x.course_id SET x.created_by=c.faculty_id");
            }
        }
        try (PreparedStatement p = c.prepareStatement("UPDATE events SET created_by=? WHERE created_by IN "
                + "(SELECT id FROM users WHERE role='FACULTY' AND email NOT IN (" + placeholders + "))")) {
            p.setLong(1, tirth); bindEmails(p, 2); p.executeUpdate();
        }
        try (PreparedStatement p = c.prepareStatement("UPDATE notifications SET created_by=? WHERE created_by IN "
                + "(SELECT id FROM users WHERE role='FACULTY' AND email NOT IN (" + placeholders + "))")) {
            p.setLong(1, tirth); bindEmails(p, 2); p.executeUpdate();
        }
        try (PreparedStatement p = c.prepareStatement("INSERT IGNORE INTO notification_reads(notification_id,user_id) "
                + "SELECT nr.notification_id,? FROM notification_reads nr JOIN users u ON u.id=nr.user_id "
                + "WHERE u.role='FACULTY' AND u.email NOT IN (" + placeholders + ")")) {
            p.setLong(1, tirth); bindEmails(p, 2); p.executeUpdate();
        }
        try (PreparedStatement p = c.prepareStatement("DELETE nr FROM notification_reads nr JOIN users u ON u.id=nr.user_id "
                + "WHERE u.role='FACULTY' AND u.email NOT IN (" + placeholders + ")")) {
            bindEmails(p, 1); p.executeUpdate();
        }
        try (PreparedStatement p = c.prepareStatement("DELETE FROM users WHERE role='FACULTY' AND email NOT IN (" + placeholders + ")")) {
            bindEmails(p, 1); p.executeUpdate();
        }

        try (PreparedStatement p = c.prepareStatement("INSERT IGNORE INTO enrolments(course_id,student_id) "
                + "SELECT c.id,u.id FROM courses c JOIN users u ON u.role='STUDENT' AND u.active=TRUE WHERE c.code IN (" + placeholders + ")")) {
            bindCourseCodes(p, 1); p.executeUpdate();
        }
    }

    private static void renameLegacyCourse(Connection c, String oldCode, Faculty replacement, long facultyId) throws SQLException {
        try (PreparedStatement p = c.prepareStatement("UPDATE courses SET code=?,title=?,faculty_id=? WHERE code=?")) {
            p.setString(1, replacement.code()); p.setString(2, replacement.title()); p.setLong(3, facultyId); p.setString(4, oldCode); p.executeUpdate();
        }
    }

    private static void bindEmails(PreparedStatement p, int start) throws SQLException {
        for (int i = 0; i < EMAILS.length; i++) p.setString(start + i, EMAILS[i]);
    }

    private static void bindCourseCodes(PreparedStatement p, int start) throws SQLException {
        for (int i = 0; i < PEOPLE.length; i++) p.setString(start + i, PEOPLE[i].code());
    }

    public static void migrateLocalDatabase() throws SQLException {
        try (Connection c = Database.connect()) {
            c.setAutoCommit(false);
            try { apply(c); c.commit(); }
            catch (Exception e) { c.rollback(); if (e instanceof SQLException sql) throw sql; throw new SQLException("Faculty roster setup failed.", e); }
        }
    }
}
