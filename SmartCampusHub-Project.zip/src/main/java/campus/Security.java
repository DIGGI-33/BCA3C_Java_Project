package campus;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.*;
import java.util.*;

public final class Security {
    private Security() {}
    public static String hash(char[] password) {
        byte[] salt = new byte[16]; new SecureRandom().nextBytes(salt);
        byte[] key = derive(password, salt);
        return "pbkdf2$210000$" + Base64.getEncoder().encodeToString(salt) + "$" + Base64.getEncoder().encodeToString(key);
    }
    public static boolean verify(char[] password, String stored) {
        try {
            String[] p = stored.split("\\$"); if (p.length != 4 || !p[0].equals("pbkdf2")) return false;
            byte[] got = derive(password, Base64.getDecoder().decode(p[2]));
            return MessageDigest.isEqual(got, Base64.getDecoder().decode(p[3]));
        } catch (RuntimeException e) { return false; }
    }
    private static byte[] derive(char[] password, byte[] salt) {
        try { PBEKeySpec spec = new PBEKeySpec(password, salt, 210000, 256); try { return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded(); } finally { spec.clearPassword(); } }
        catch (GeneralSecurityException e) { throw new IllegalStateException("Secure password hashing is unavailable", e); }
    }
}
