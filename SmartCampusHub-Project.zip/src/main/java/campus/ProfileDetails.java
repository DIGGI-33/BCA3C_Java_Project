package campus;

/** Optional role-specific contact and academic/workplace details. */
public record ProfileDetails(String phone, String designation, String department,
                             String officeLocation, String availability, String program,
                             Integer semester, String batch, String section) {}
