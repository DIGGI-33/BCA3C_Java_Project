@echo off
call build.bat
if errorlevel 1 exit /b 1
java -cp "build\classes;lib\mysql-connector-j-26.7.0.jar" campus.Main --test-db
