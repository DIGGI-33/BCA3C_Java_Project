Smart Campus Hub project ZIP

Contains Java source, database scripts, documentation, tests, build scripts, MySQL Connector/J, and the current runnable JAR.

For privacy, local.properties and local-admin.txt are not included. Copy local.properties.example to local.properties and enter your own MySQL password before running. The Windows app image is excluded because its bundled Java runtime would exceed the 25 MB limit.

