@echo off
call build.bat
if errorlevel 1 exit /b 1
set "JAVA_BIN="
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\java.exe" set "JAVA_BIN=%JAVA_HOME%\bin"
if not defined JAVA_BIN for /d %%D in ("%ProgramFiles%\Java\jdk-*") do if exist "%%~D\bin\java.exe" set "JAVA_BIN=%%~D\bin"
if defined JAVA_BIN (
  "%JAVA_BIN%\java.exe" -cp "build\classes;lib\mysql-connector-j-26.7.0.jar" campus.Main %*
) else (
  java -cp "build\classes;lib\mysql-connector-j-26.7.0.jar" campus.Main %*
)
